import factory
from factory.django import DjangoModelFactory

from .models import Information

class InformationFactory(DjangoModelFactory):
    class Meta:
        model = Information

    title = factory.Faker("sentence")
    contents = factory.Faker("paragraph",nb_sentences=10,variable_nb_sentences=True)