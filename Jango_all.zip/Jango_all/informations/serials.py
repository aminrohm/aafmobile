from rest_framework import serializers
from .models import Information,Picture
from products.serials import PictureSerializer

#class PictureSerializer(serializers.ModelSerializer):
#    class Meta:
#        model = Picture
#        fields =['picture']

class InformationSerializer(serializers.ModelSerializer):
    images = PictureSerializer(read_only=True,many=True)
    class Meta:
        model = Information
        fields ='__all__'