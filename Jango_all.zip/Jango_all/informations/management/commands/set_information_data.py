from informations.models import Picture,Information
import os
from django.db import transaction
from informations.factories import InformationFactory
from django.core.management.base import BaseCommand
import random
import time


picture_list=  ["/home/ayuhana/django/asiafmobile/imagex/lamorgini.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/agriculture.png",
                "/home/ayuhana/django/asiafmobile/imagex/p_alphard.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/p_brv.png",
                "/home/ayuhana/django/asiafmobile/imagex/p_crv.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/p_fortuner.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/p_innova.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/p_lamorgini.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/p_mobilio.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c1a.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c1b.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c1c.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c2bh.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c2bi.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c2bm.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c2ch.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c2ci.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c2cm.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c2di.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c2h.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c2i.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c2m.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c3bm.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c3h.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c3i.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c3m.jpg",
                #Category Niaga 1
                "/home/ayuhana/django/asiafmobile/imagex/c1_flatdeck.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c1_mobilbox.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c1_mobilbox_freezer.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c1_pickup.jpg",
                #Category Niaga 2
                "/home/ayuhana/django/asiafmobile/imagex/c2_dumptruck.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c2_flatdeck.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c2_microbus.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c2_mobilbox.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c2_mobilbox_freezer.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c2_truck_mixer.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c2_truck_tangki.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c2_truck.png",
                #Category Niaga 3
                "/home/ayuhana/django/asiafmobile/imagex/c3_crane.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c3_headtractor.png",
                "/home/ayuhana/django/asiafmobile/imagex/c3_wingbox.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/p_jeep.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/p_minibus.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/p_others.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/p_sedan.jpg"]

class Command(BaseCommand):
    
    @transaction.atomic
    def handle(self,*arg,**kwargs):
        self.stdout.write("Deleting old key")
        Information.objects.all().delete()
        random.seed(time.time())
        for info in range(0,100):
            info = InformationFactory()
            img_id_list = [random.randrange(1,44),random.randrange(1,44),random.randrange(1,44)]
            img_list = [Picture.objects.get(picture=picture_list[i]) for i in img_id_list ]
            #img = Picture.objects.filter(picture__in=img_list)
            info.images.set(img_list)
               
