from django.shortcuts import render
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status
from django.http import Http404
from .serials import InformationSerializer
from .models import Information

# Create your views here.
class GetInformation(APIView):
    def get(self,request,id=None):
        if id:
            information = Information.objects.get(id=id)
            print(information)
            serializer = InformationSerializer(information)
            print(serializer.data['images'])
            return Response(serializer.data, status=status.HTTP_200_OK)

        information = Information.objects.all()
        print(information)
        serializer = InformationSerializer(information,many=True)
        #print(serializer.data)
        return Response(serializer.data,status=status.HTTP_200_OK)