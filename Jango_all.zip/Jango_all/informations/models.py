from django.db import models
from products.models import Picture

# Create your models here.
#class Picture(models.Model):
#    picture =  models.ImageField(upload_to='images/information/')
#    def __str__(self):
#        return self.picture.url
    
class Information(models.Model):
    title = models.CharField(max_length=255)
    images = models.ManyToManyField(Picture,blank=True,related_name="information_picture_of")
    contents = models.TextField()
    
    def __str__(self):
        return self.title