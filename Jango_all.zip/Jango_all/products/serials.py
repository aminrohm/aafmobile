from rest_framework import serializers
from .models import Product,ProductClassification, ProductBrand, Picture, ProductCategory,ProductSpecification,Transmisi,BahanBakar

class ProductClassificationSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProductClassification
        fields = '__all__'


class TransmisiSerializer(serializers.ModelSerializer):
    class Meta:
        model = Transmisi
        fields =['name']

class BahanBakarSerializer(serializers.ModelSerializer):
    class Meta:
        model = BahanBakar
        fields = ['name']

class PictureSerializer(serializers.ModelSerializer):
    class Meta:
        model = Picture
        fields =['picture']

class ProductCategorySerializer(serializers.ModelSerializer):
    rep_image = PictureSerializer(read_only=True,many=True)
    #classification = ProductClassificationSerializer(read_only=True)
    class Meta:
        model = ProductCategory
        fields = '__all__'

class ProductBrandSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProductBrand
        fields = ['name']

class ProductSpecificationSerializer(serializers.ModelSerializer):
    transmisi = TransmisiSerializer()
    bahan_bakar = BahanBakarSerializer()
    class Meta:
        model = ProductSpecification
        fields = '__all__'

class ProductSerializer(serializers.ModelSerializer):
    name =  serializers.CharField()
    image = PictureSerializer(read_only=True,many=True)
        #many=True,
        #view_name='product-detail',
        #lookup_field='id',
        #read_only=True
 
    category = ProductCategorySerializer(read_only=True)
    brand = ProductBrandSerializer(read_only=True)
    specification = ProductSpecificationSerializer(read_only=True)
    harga_otr = serializers.IntegerField()

    # category = serializers.HyperlinkedRelatedField(
    #     many=True,
    #     view_name='product-detail',
    #     #lookup_field='id',
    #     read_only=True
    # )
    # brand = serializers.HyperlinkedRelatedField(
    #     many=True,
    #     view_name='productbrand-detail',
    #     #lookup_field='id',
    #     read_only=True
    # )
    # specification = serializers.HyperlinkedRelatedField(
    #     many=True,
    #     view_name='specification-detail',
    #     #lookup_field='id',
    #     read_only=True
    # )
    class Meta:
        model = Product 
        fields = '__all__'

class ProductClassificationSerializer(serializers.ModelSerializer):
    rep_image = PictureSerializer(
        many=True,
        #lookup_field='id',
        read_only=True
    )
    class Meta:
        model = ProductClassification 
        fields = '__all__'

class ProductBrandSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProductBrand 
        fields = '__all__'