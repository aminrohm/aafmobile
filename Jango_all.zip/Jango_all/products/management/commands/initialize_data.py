from products.models import Product,ProductClassification,ProductSpecification,Transmisi,BahanBakar,Picture,ProductCategory,ProductBrand
import os
from django.db import transaction
from django.core.management.base import BaseCommand


transmisi_list = ['Automatic','Manual']
bahanbakar_list = ['Avtur','Solar','Bensin']
dimensi_list = ['30mx20m','10mx20m','5mx5m']

picture_list=  ["/imagex/lamorgini.jpg",
                "/imagex/agriculture.png",
                "/imagex/p_alphard.jpg",
                "/imagex/p_brv.png",
                "/imagex/p_crv.jpg",
                "/imagex/p_fortuner.jpg",
                "/imagex/p_innova.jpg",
                "/imagex/p_lamorgini.jpg",
                "/imagex/p_mobilio.jpg",
                "/imagex/c1a.jpg",
                "/imagex/c1b.jpg",
                "/imagex/c1c.jpg",
                "/imagex/c2bh.jpg",
                "/imagex/c2bi.jpg",
                "/imagex/c2bm.jpg",
                "/imagex/c2ch.jpg",
                "/imagex/c2ci.jpg",
                "/imagex/c2cm.jpg",
                "/imagex/c2di.jpg",
                "/imagex/c2h.jpg",
                "/imagex/c2i.jpg",
                "/imagex/c2m.jpg",
                "/imagex/c3bm.jpg",
                "/imagex/c3h.jpg",
                "/imagex/c3i.jpg",
                "/imagex/c3m.jpg",
                #Category Niaga 1
                "/imagex/c1_flatdeck.jpg",
                "/imagex/c1_mobilbox.jpg",
                "/imagex/c1_mobilbox_freezer.jpg",
                "/imagex/c1_pickup.jpg",
                #Category Niaga 2
                "/imagex/c2_dumptruck.jpg",
                "/imagex/c2_flatdeck.jpg",
                "/imagex/c2_microbus.jpg",
                "/imagex/c2_mobilbox.jpg",
                "/imagex/c2_mobilbox_freezer.jpg",
                "/imagex/c2_truck_mixer.jpg",
                "/imagex/c2_truck_tangki.jpg",
                "/imagex/c2_truck.png",
                #Category Niaga 3
                "/imagex/c3_crane.jpg",
                "/imagex/c3_headtractor.png",
                "/imagex/c3_wingbox.jpg",
                "/imagex/p_jeep.jpg",
                "/imagex/p_minibus.jpg",
                "/imagex/p_others.jpg",
                "/imagex/p_sedan.jpg"]



brand_list=["AUDI",
            "BENT",
            "BIMANTARA",
            "BMW",
            "CHEVROLET",
            "CHRYSLER",
            "DAEWOO",
            "DAIHATSU",
            "FORD",
            "Hitachi",
            "Caterpillar",
            "Komatsu",
            "China Textmat",
            "NEC",
            "HINO",
            "MITSUBISHI",
            "HONDA",
            "TOYOTA",
            "ISUZU",
            "KIA",
            "KAWASAKI",
            "MAZDA",
            "NISSAN",
            "SUZUKI",
            "YAMAHA"]

category_list =[
    #Agriculture
                "Combine",
                "Tractor",
    #Passanger
                "Sedan",
                "Jeep",
                "Minibus",
                "Other Passanger",
    #Niaga1
                "Pickup",
                "Box",
                "Box Freezer",
                "FlatDeck",
                "Other Niaga 1",
    #Niaga2
                "Truck",
                "Dump Truck",
                "Box",
                "Box Freezer",
                "Microbus",
                "Flat Deck",
                "Truck Tangki",
                "Truk Mixer",
                "Other Niaga 2",
    #Niaga3
                "Crane",
                "Wingbox",
                "Head Tractor"
                "Other Niaga 3"]

classification_list=[
    "Agriculture",
    "Passenger",
    "Niaga Category 1",
    "Niaga Category 2",
    "Niaga Category 3"
]


class Command(BaseCommand):
    
    
    @transaction.atomic
    def handle(self,*args,**kwargs):

        # self.stdout.write("Deleting old data")
        # models = [Picture]
        # for m in models:
        #     m.objects.all().delete()


        # for i in os.listdir('/home/ayuhana/django/asiafmobile/imagex'):
        #     print(i)
        #     pic = Picture(picture=os.path.join('/home/ayuhana/django/asiafmobile/imagex',i))
        #     pic.save()


        # for i in brand_list:
        #     brand = ProductCate(name=i)
        #     brand.save()


        #picture='/home/ayuhana/django/asiafmobile/imagex/lamorgini.jpg' #+picture_list[0]
        #print(picture)
        
        #obj = Picture.objects.get(picture=picture)
        #print(obj.picture)
        #xx = Picture.objects.all()
#        for i in xx:
#           print(i.picture)

        for i in classification_list:
            classi=ProductClassification.objects.create(name=i)
            if i=="Agriculture":
                for j in range(0,2):
                    cate=ProductCategory.objects.create(classification=classi,name=category_list[j])
                    print(picture_list[j])
                    cate.rep_image.set([Picture.objects.get(picture='/home/ayuhana/django/asiafmobile'+picture_list[j])])
            classi.rep_image.set([Picture.objects.get(picture=os.path.join('/home/ayuhana/django/asiafmobile/imagex/','agriculture.png'))])   

            if i=="Passenger":
                for j in range(2,6):
                    cate=ProductCategory.objects.create(classification=classi,name=category_list[j])
                    cate.rep_image.set([Picture.objects.get(picture='/home/ayuhana/django/asiafmobile'+picture_list[j])])
            #classi.rep_image.set(Picture.objects.get(picture='\imagex\p_innova.jpg'))    
            classi.rep_image.set([Picture.objects.get(picture=os.path.join('/home/ayuhana/django/asiafmobile/imagex/','p_innova.jpg'))])              

            if i=="Niaga Category 1":
                for j in range(6,11):
                    cate=ProductCategory.objects.create(classification=classi,name=category_list[j])
                    cate.rep_image.set([Picture.objects.get(picture='/home/ayuhana/django/asiafmobile'+picture_list[j])])
            #classi.rep_image.set(Picture.objects.get(picture='\imagex\c1a.jpg'))  
            classi.rep_image.set([Picture.objects.get(picture=os.path.join('/home/ayuhana/django/asiafmobile/imagex','c1a.jpg'))])   

            if i=="Niaga Category 2":
                for j in range(11,20):
                    cate=ProductCategory.objects.create(classification=classi,name=category_list[j])
                    cate.rep_image.set([Picture.objects.get(picture='/home/ayuhana/django/asiafmobile'+picture_list[j])])
            #classi.rep_image.set(Picture.objects.get(picture='\imagex\c2_dumptruck.jpg'))  
            classi.rep_image.set([Picture.objects.get(picture=os.path.join('/home/ayuhana/django/asiafmobile/imagex','c2_dumptruck.jpg'))])   

            if i=="Niaga Category 3":
                for j in range(20,23):
                    cate=ProductCategory.objects.create(classification=classi,name=category_list[j])
                    cate.rep_image.set([Picture.objects.get(picture='/home/ayuhana/django/asiafmobile'+picture_list[j])])
            #classi.rep_image.set(Picture.objects.get(picture='\imagex\c3_crane.jpg'))  
            classi.rep_image.set([Picture.objects.get(picture=os.path.join('/home/ayuhana/django/asiafmobile/imagex','c3_crane.jpg'))])   