#setup_test_data.ppy

import random
from django.db import transaction
from django.core.management.base import BaseCommand

import time

from products.models import Product,ProductSpecification,Transmisi,BahanBakar,Picture,ProductCategory,ProductBrand
from products.factories import (
    ProductFactory,
    ProductSpecificationFactory
)

NUM_PRODUCTS = 100
NUM_SPECIFICATIONS = 100

transmisi_list = ['Automatic','Manual']
bahanbakar_list = ['Avtur','Solar','Bensin']
dimensi_list = ['30mx20m','10mx20m','5mx5m']

picture_list=  ["/home/ayuhana/django/asiafmobile/imagex/lamorgini.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/agriculture.png",
                "/home/ayuhana/django/asiafmobile/imagex/p_alphard.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/p_brv.png",
                "/home/ayuhana/django/asiafmobile/imagex/p_crv.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/p_fortuner.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/p_innova.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/p_lamorgini.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/p_mobilio.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c1a.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c1b.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c1c.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c2bh.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c2bi.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c2bm.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c2ch.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c2ci.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c2cm.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c2di.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c2h.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c2i.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c2m.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c3bm.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c3h.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c3i.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c3m.jpg",
                #Category Niaga 1
                "/home/ayuhana/django/asiafmobile/imagex/c1_flatdeck.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c1_mobilbox.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c1_mobilbox_freezer.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c1_pickup.jpg",
                #Category Niaga 2
                "/home/ayuhana/django/asiafmobile/imagex/c2_dumptruck.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c2_flatdeck.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c2_microbus.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c2_mobilbox.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c2_mobilbox_freezer.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c2_truck_mixer.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c2_truck_tangki.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c2_truck.png",
                #Category Niaga 3
                "/home/ayuhana/django/asiafmobile/imagex/c3_crane.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/c3_headtractor.png",
                "/home/ayuhana/django/asiafmobile/imagex/c3_wingbox.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/p_jeep.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/p_minibus.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/p_others.jpg",
                "/home/ayuhana/django/asiafmobile/imagex/p_sedan.jpg"]



brand_list=["AUDI",
            "BENT",
            "BIMANTARA",
            "BMW",
            "CHEVROLET",
            "CHRYSLER",
            "DAEWOO",
            "DAIHATSU",
            "FORD",
            "Hitachi",
            "Caterpillar",
            "Komatsu",
            "China Textmat",
            "NEC",
            "HINO",
            "MITSUBISHI",
            "HONDA",
            "TOYOTA",
            "ISUZU",
            "KIA",
            "KAWASAKI",
            "MAZDA",
            "NISSAN",
            "SUZUKI",
            "YAMAHA"]

category_list =[
    #Agriculture
                "Combine",
                "Tractor",
    #Passanger
                "Sedan",
                "Jeep",
                "Minibus",
                "Other Passanger",
    #Niaga1
                "Pickup",
                "Box",
                "Box Freezer",
                "FlatDeck",
                "Other Niaga 1",
    #Niaga2
                "Truck",
                "Dump Truck",
                "Box",
                "Box Freezer",
                "Microbus",
                "Flat Deck",
                "Truck Tangki",
                "Truk Mixer",
                "Other Niaga 2",
    #Niaga3
                "Crane",
                "Wingbox",
                "Head Tractor"
                "Other Niaga 3"]

class Command(BaseCommand):
    help = "Generates test data"

    @transaction.atomic
    def handle(self,*args,**kwargs):
        self.stdout.write("Deleting old data")
        models = [Product,ProductSpecification]
        for m in models:
            m.objects.all().delete()

        self.stdout.write("Creating new data")
        random.seed(time.time())
        productspecifications = []
        for _ in range(NUM_PRODUCTS):
            productspecification= ProductSpecificationFactory(
                manufacturing_year= random.randrange(2015,2023), 
                transmisi = Transmisi.objects.get(name=random.choice(transmisi_list)),
                kilometer = str(random.randrange(100,1000)),
                bahan_bakar = BahanBakar.objects.get(name=random.choice(bahanbakar_list)),
                konsumsi_bbm = random.randrange(100,200),
                torsi = random.randrange(10,100),
                kapasitas_mesin = random.randrange(500,2000),
                kapasitas_penumpang = random.randrange(2,100),
                dimensi = random.choice(dimensi_list),
            )
            productspecifications.append(productspecification)

        products = []
        for spec in productspecifications:
            product= ProductFactory(
                name = random.choice(brand_list)+" "+random.choice(["XYZ","UIE","ABC"])+str(random.randrange(100,999)),
                #image = [Picture.objects.get(id=random.randrange(1,45)),Picture.objects.get(id=random.randrange(1,45)),Picture.objects.get(id=random.randrange(1,45))],
                category = ProductCategory.objects.filter(name=random.choice(category_list)).first(),
                #if category=""
                brand = ProductBrand.objects.filter(name=random.choice(brand_list)).first(),
                harga_otr = random.randrange(100_000_000,2_000_000_000),
                specification = spec,
            )
            img_id_list = [random.randrange(1,44),random.randrange(1,44),random.randrange(1,44)]
            img_list = [Picture.objects.get(picture=picture_list[i]) for i in img_id_list ]
            #img = Picture.objects.filter(picture__in=img_list)
            product.image.set(img_list)
            products.append(product)        