from django.contrib import admin
from .models import Picture,ProductClassification,ProductCategory,ProductBrand,Transmisi,BahanBakar,ProductSpecification,Product

# Register your models here.


@admin.register(ProductClassification)
class ProductClassificationAdmin(admin.ModelAdmin):
  pass
  
@admin.register(ProductCategory)
class ProductCategoryAdmin(admin.ModelAdmin):
  pass
  
@admin.register(ProductBrand)
class ProductBrandAdmin(admin.ModelAdmin):
  pass
  
@admin.register(Transmisi)
class TransmisiAdmin(admin.ModelAdmin):
  pass
  
@admin.register(BahanBakar)
class BahanBakarAdmin(admin.ModelAdmin):
  pass
  
@admin.register(ProductSpecification)
class ProductSpecification(admin.ModelAdmin):
  pass

#@admin.register(Picture)
class PictureInline(admin.StackedInline):
  model= Product.image.through
  
  
@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
  inlines = [PictureInline]
  model = Product
  
  def get_inline_instances(self,request,obj=None):
    if not obj:
        return list()
    return super(ProductAdmin,self).get_inline_instances(request,obj)
  
admin.site.register(Picture)  