"""
URL configuration for asiafmobile project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,include,re_path
from rest_framework import routers,serializers,viewsets
#from products.models import Product,ProductClassification, ProductBrand, Picture, ProductCategory,ProductSpecification,Transmisi,BahanBakar
from products.views import GetProduct,GetProductSpecification,GetProductByClassification
from informations.views import GetInformation
from django.conf import settings
from django.conf.urls.static import static

#class ProductSerializer(serializers.HyperlinkedModelSerializer):



# class ProductViewSet(viewsets.ModelViewSet):
#     queryset = Product.objects.all()
#     serializer_class = ProductSerializer

# class ProductClassificationViewSet(viewsets.ModelViewSet):
#     queryset = ProductClassification.objects.all()
#     serializer_class = ProductClassificationSerializer

# class ProductBrandViewSet(viewsets.ModelViewSet):
#     queryset = ProductBrand.objects.all()
#     serializer_class = ProductBrandSerializer

#router = routers.DefaultRouter()
#router.register(r'products',ProductViewSet)
#router.register(r'class',ProductClassificationViewSet)
#router.register(r'brand',ProductBrandViewSet)

urlpatterns = [
    path('admin/', admin.site.urls),
#    path('',include(router.urls)),
    path('product/',GetProduct.as_view()),
    path('product/<int:id>/',GetProduct.as_view()),
    path('info/',GetInformation.as_view()),
    path('info/<int:id>/',GetInformation.as_view()),
    path('prod-spec/<int:id>/',GetProductSpecification.as_view()),
    path('prod-by-class/<int:id>/',GetProductByClassification.as_view()),
    path('api-auth/',include('rest_framework.urls')),
    #re_path(r'^imagex/(?P<path>.*)$',django.views.static.serve,{'media_root':settings.MEDIA_ROOT})
]+ static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)
