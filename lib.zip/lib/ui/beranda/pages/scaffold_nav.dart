import 'package:flutter/material.dart';
//import 'package:aafmobile/ui/home/widgets/all_games_widget/all_games_widget.dart';
//import 'package:infogames/ui/home/widgets/category_widget/categories_widget.dart';
//import 'package:infogames/ui/home/widgets/games_by_category_widget/games_by_category_widget.dart';
//import 'package:infogames/ui/home/widgets/header_title/header_title.dart';
//import 'package:infogames/ui/widgets/container_body.dart';
import 'package:aafmobile/ui/beranda/widgets/informasi_widget/informasi_widget.dart';
import 'package:aafmobile/ui/beranda/pages/beranda_page.dart';
import 'package:aafmobile/ui/akun/pages/akun_page.dart';
import 'package:aafmobile/ui/promo/pages/promo_page.dart';
import 'package:aafmobile/ui/bantuan/pages/bantuan_page.dart';
import 'package:go_router/go_router.dart';
//import 'package:aafmobile/ui/beranda/widgets/category_widget//';

class ScaffoldNav extends StatelessWidget {
  //const BerandaLayout({
  //  Key? key,
  //}) : super(key: key);
  const ScaffoldNav(this.navigationShell, {super.key});

  final StatefulNavigationShell navigationShell;


  @override
  Widget build(BuildContext context) {
    /*
    return Padding(
      padding: const EdgeInsets.only(top: 80.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          //HeaderTitle(),
          const SizedBox(height: 40.0),
          ContainerBody(
            children: [
              InformasiWidget(),
              CategoryWidget(),
              //AllGamesWidget(title: 'All games'),
            ],
          )
        ],
      ),
    );
    */
    return Scaffold(
      appBar: AppBar(
        title: const Text('Asiaf Mobile'),
        backgroundColor: Colors.red,
      ),
      body: navigationShell,
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        backgroundColor: Colors.black,
        selectedItemColor: Colors.greenAccent,
        unselectedItemColor:Colors.grey,
        currentIndex: navigationShell.currentIndex,
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.star), label: 'Promo'),
          BottomNavigationBarItem(icon: Icon(Icons.people), label: 'Akun'),
          BottomNavigationBarItem(
              icon: Icon(Icons.question_mark), label: 'Bantuan'),
        ],
        onTap: _onTap,
      ),
    );
  }


  void _onTap(index) {
    navigationShell.goBranch(
      index,
      initialLocation: index == navigationShell.currentIndex,
    );
  }

}

