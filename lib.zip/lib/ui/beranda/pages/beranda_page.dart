import 'package:aafmobile/db/virtual_db.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
//import 'package:aafmobile/repositories/asiafmobile_interface.dart';
import 'package:aafmobile/repositories/asiafmobile.dart';
import 'package:aafmobile/ui/beranda/widgets/informasi_widget/bloc/informasi_bloc.dart';
//import 'package:aafmobile/ui/beranda/widgets/category_widget/bloc/category_bloc.dart';
import 'package:aafmobile/ui/beranda/pages/beranda_layout.dart';
import 'package:aafmobile/repositories/service/asiafmobile.dart';


class BerandaPage extends StatelessWidget {
  const BerandaPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
    body:RepositoryProvider(
        create: (context) => AsiafMobileRepository(service: AsiafMobileService()),
        child: MultiBlocProvider(
          providers: [
            BlocProvider<InformasiBloc>(
              create: (context) => InformasiBloc(
                //activePage:1,
                asiafmobileRepository: context.read<AsiafMobileRepository>(),
              )..add(GetAllInformasiEvent()),
            ),
            /*
            BlocProvider<CategoryBloc>(
              create: (context) => CategoryBloc(
                AsiafMobileRepository: context.read<AsiafMobileRepository>(),
              )..add(GetAllCategory()),
            ),
             */
          ],
          child: BerandaLayout(),
        ),
      ),
    );
  }
}
