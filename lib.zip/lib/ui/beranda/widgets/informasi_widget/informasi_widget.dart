import 'package:aafmobile/repositories/asiafmobile.dart';
import 'package:aafmobile/repositories/service/asiafmobile.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:aafmobile/ui/beranda/widgets/informasi_widget/bloc/informasi_bloc.dart';
import 'package:aafmobile/repositories/models/informasi.dart';
import 'package:carousel_indicator/carousel_indicator.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:dots_indicator/dots_indicator.dart';
import 'package:aafmobile/ui/informasi/pages/informasi_detail_page.dart';
import 'package:aafmobile/ui/routers/router.dart';


TValue? case2<TOptionType, TValue>(
    TOptionType selectedOption,
    Map<TOptionType, TValue> branches, [
      TValue? defaultValue = null,
    ]) {
  if (!branches.containsKey(selectedOption)) {
    return defaultValue;
  }

  return branches[selectedOption];
}


class InformasiWidget extends StatelessWidget {
  const InformasiWidget({Key? key}) : super(key: key);



  @override
  Widget build(BuildContext context){
    return BlocConsumer<InformasiBloc,InformasiState>(
      listener: (context,state){

      },
      builder: (context,state) {
        //return Container(
        if (state is InformasiErrorState) {
          return Text("Error");
        }
        if (state is InformasiLoadingState) {
          return CircularProgressIndicator();
        }
        if (state is AllInformasiLoadedState) {
          List<Informasi> list_informasi = state.list_informasi;
          List<String> list_image = [];
          for (var i = 0; i < list_informasi.length; i++) {
            list_image.add(list_informasi[i].image_url);
          }
          //return _buildImageCarouselWithIndicator(list_image, context);
          return Column(
            children: [
              CarouselSlider(
                options: CarouselOptions(
                  disableCenter: true,
                  onPageChanged: (index,reason){
                    BlocProvider.of<InformasiBloc>(context).add(
                      InformasiPageChangeEvent(list_informasi:state.list_informasi,index:index)
                    );
                    //current_pos = index;
                  },
                ),
                items: list_image.map((imageUrl) {
                  return InkWell(
                    splashColor: Colors.deepOrangeAccent,
                    onTap:() {
                      //BlocProvider.of<InformasiBloc>(context).add(GetOneInformasiEvent(data: state.activePage));
                      router.go('/beranda/informasi-details/'+state.activePage.toString());

                      },
                    //onTap: () => router.goNamed('informasi-detail'),
                    child: Image.network(
                      imageUrl,
                      fit: BoxFit.cover,
                    ),
                  );
                }).toList(),
                //autoplay: true,
                //interval: Duration(seconds: 3),
              ),
              Container(
                //bottom: 0,
                //left: 0,
                //right: 0,
                child: DotsIndicator(
                  dotsCount: list_image.length,
                  //position: state.currentPage.toDouble(),
                  //position: current_pos.toDouble(),
                  position: state.activePage.toDouble(),
                ),
              ),
            ],
          );
        }
        return Container();
      }
      );
      }
    //);

    /*
    return BlocProvider(
      //buildWhen: (previous,current) => current.status.isSuccess,
      create: (context) => InformasiBloc(asiafmobileRepository: AsiafMobileRepository(service: AsiafMobileService())),
      child: BlocConsumer<InformasiBloc,InformasiState>(
        listener: (context,state){
          //
        },
        //child: BlocBuilder<InformasiBloc,InformasiState>(
          builder: (context,state) {
            if(state is InformasiErrorState)
              {
                return Text("Error");
              }
            if(state is InformasiLoadingState)
            {
              return CircularProgressIndicator();
            }
            if(state is AllInformasiLoadedState)
              {
                List<Informasi> list_informasi = state.list_informasi;
                List<String> list_image = [];
                for(var i=0;i<list_informasi.length;i++) {
                  list_image.add(list_informasi[i].image_url);
                }
                /*
                return Column(
                  children: [
                    Container(
                      height:300,
                      child:PageView.builder(
                            itemCount: list_informasi.length,
                            pageSnapping: true,
                    //onPageChanged: (page) => context.read<InformasiBloc>().add(InformasiPageChange(data:page)),
                            //onPageChanged: (page) => context.read<InformasiBloc>().add(InformasiPageChange(data:page)),
                              itemBuilder: (context, pagePosition) {
                                  List<String> list_image = [];
                                  for(var i=0;i<list_informasi.length;i++) {
                                      list_image.add(list_informasi[i].image_url);
                                   }
                                  return Container(
                                      margin: EdgeInsets.all(10),
                                      child: InkWell(
                                          splashColor: Colors.greenAccent,
                                          onTap: () {},
                                          child: Image.network(list_image[pagePosition], fit: BoxFit.cover,),
                                    ),
                              );
                              },
                    )),
                //CarouselIndicator(
                //  count: list_informasi.length,
                //  index: state.activePage,
                //),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children:indicators(list_informasi.length,_activePage),
                    ),
                //);
                  ],
                );
                
                 */
                return _buildImageCarouselWithIndicator(list_image,context);
              }

            return Container();
        }
        //),
      ),
    );

     */

     
  }


//}


/*
List<Widget> indicators(imagesLength,currentIndex) {
  return List<Widget>.generate(imagesLength, (index) {
    return Container(
      margin: EdgeInsets.all(3),
      width: 10,
      height: 10,
      decoration: BoxDecoration(
          color: currentIndex == index ? Colors.black : Colors.black26,
          shape: BoxShape.circle),
    );
  });
}
*/

