import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:aafmobile/ui/beranda/widgets/informasi_widget/bloc/informasi_bloc.dart';
import 'package:aafmobile/repositories/models/informasi.dart';


TValue? case2<TOptionType, TValue>(
    TOptionType selectedOption,
    Map<TOptionType, TValue> branches, [
      TValue? defaultValue = null,
    ]) {
  if (!branches.containsKey(selectedOption)) {
    return defaultValue;
  }

  return branches[selectedOption];
}


class InformasiWidget extends StatelessWidget {
  const InformasiWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context){
    return BlocBuilder<InformasiBloc,InformasiState>(
      //buildWhen: (previous,current) => current.status.isSuccess,
      builder: (context,state) {
            if(state is InformasiErrorState)
              {
                return Text("Error");
              }
            if(state is InformasiLoadingState)
            {
              return CircularProgressIndicator();
            }
            if(state is AllInformasiLoadedState)
              {
                List<Informasi> list_informasi = state.list_informasi;
                return SizedBox(
                    child:PageView.builder(
                    itemCount: list_informasi.length,
                    pageSnapping: true,
                    //onPageChanged: (page) => context.read<InformasiBloc>().add(InformasiPageChange(data:page)),
                      onPageChanged: (page) => context.read<InformasiBloc>(activePage:page);
                      itemBuilder: (context, pagePosition) {
                      List<String> list_image = [];
                      for(var i=0;i<list_informasi.length;i++) {
                      list_image.add(list_informasi[i].image_url);
                      }
                      return Container(
                        margin: EdgeInsets.all(10),
                        child: InkWell(
                          splashColor: Colors.greenAccent,
                          onTap: () {},
                          child: Image.network(list_image[pagePosition], fit: BoxFit.cover,),
                        ),
                    );
                  },)
                );
              }
            return Container();
        }
    );
  }
}

List<Widget> indicators(imagesLength,currentIndex) {
  return List<Widget>.generate(imagesLength, (index) {
    return Container(
      margin: EdgeInsets.all(3),
      width: 10,
      height: 10,
      decoration: BoxDecoration(
          color: currentIndex == index ? Colors.black : Colors.black26,
          shape: BoxShape.circle),
    );
  });
}


