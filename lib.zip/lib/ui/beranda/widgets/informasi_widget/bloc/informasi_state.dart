part of 'informasi_bloc.dart';

/*
enum InformasiStatus {initial,success,error,loading}

extension InformasiStatusX on InformasiStatus {
  bool get isInitial => this => InformasiStatus.initial;
  bool get isSuccess => this => InformasiStatus.success;
  bool get isError => this => InformasiStatus.error;
  bool get isLoading => this => InformasiStatus.loading;
}

 */

@immutable
abstract class InformasiState extends Equatable {}

class InformasiLoadingState extends InformasiState {
  @override
  List<Object?> get props => [];
}

class AllInformasiLoadedState extends InformasiState {
  final List<Informasi> list_informasi;
  AllInformasiLoadedState(this.list_informasi);
  @override
  List<Object?> get props => [list_informasi];
}

class InformasiPageChangeState extends InformasiState {
  final int activePage;
  InformasiPageChangeState(this.activePage);
  @override
  List<Object?> get props => [activePage];
}

class OneInformasiLoadedState extends InformasiState {
  final Informasi? informasi;
  OneInformasiLoadedState(this.informasi);
  @override
  List<Object?> get props => [informasi];
}

class InformasiErrorState extends InformasiState {
  final String error;
  InformasiErrorState(this.error);
  @override
  List<Object?> get props => [error];
}

/*
class InformasiState extends Equatable {
  const InformasiState({
    this.status = InformasiStatus.initial,
    List<Informasi>? informasi,
    int idSelected =0,
    int activePage =0,
        }): informasi = informasi ?? const [],
            idSelected = idSelected,
            activePage = activePage;

  final List<Informasi> informasi;
  final InformasiStatus status;
  final int idSelected;
  final int activePage;

  @override
  List<Object?> get props => [status,informasi,idSelected,activePage];

  InformasiState copyWith({
    List<Informasi>? informasi,
    InformasiStatus? status,
    int? idSelected,
    int? activePage,
  }){
    return InformasiState(
      informasi : informasi ?? this.informasi,
      status: status ?? this.status,
      idSelected: idSelected ?? this.idSelected,
      activePage: activePage ?? this.activePage,
    );
  }
  
}

 */
