part of 'informasi_bloc.dart';

/*
enum InformasiStatus {initial,success,error,loading}

extension InformasiStatusX on InformasiStatus {
  bool get isInitial => this => InformasiStatus.initial;
  bool get isSuccess => this => InformasiStatus.success;
  bool get isError => this => InformasiStatus.error;
  bool get isLoading => this => InformasiStatus.loading;
}

 */

@immutable
abstract class InformasiStateX extends Equatable {}


class InformasiState extends Equatable {
  final List<Informasi> list_informasi;
  final int activePage;
  InformasiState({
    required this.list_informasi,
    required this.activePage,
  });

  @override
  List<Object?> get props => [list_informasi,activePage];

  factory InformasiState.initial() => InformasiState(
    list_informasi: [],
    activePage: 0,
  );

  InformasiState copyWith({
  List<Informasi>? list_informasi,
    int? activePage,
}){
    return InformasiState(
      list_informasi: list_informasi ?? this.list_informasi,
      activePage: activePage ?? this.activePage,
    );
  }

}

class InformasiLoadingState extends InformasiState {

  InformasiLoadingState():super(list_informasi:[],activePage:0);
  //@override
  //List<Object?> get props => [];
}

class AllInformasiLoadedState extends InformasiState {
  //final List<Informasi> list_informasi;
  AllInformasiLoadedState({
    required List<Informasi> list_informasi,
    required int activePage,
  }):super(list_informasi: list_informasi,activePage: activePage);

  AllInformasiLoadedState copyWith({
    List<Informasi>? list_informasi,
    int? activePage,
  }) {
    return AllInformasiLoadedState(
      list_informasi: list_informasi ?? this.list_informasi,
      activePage: activePage ?? this.activePage,
    );
  }

  @override
  String toString() {
    return 'AllInformasiLoaded(list_informasi: $list_informasi, activePage: $activePage)';
  }

  //@override
  //List<Object?> get props => [list_informasi]; // decides which objects we should consider for object coprison.
}

class InformasiPageChangeState extends InformasiState {
  //List<Informasi>? list_informasi;
  //int? activePage;
  final int index;
  InformasiPageChangeState({
    required this.index,
}):super(list_informasi:const [],activePage: index);

  InformasiPageChangeState copyWith({
  List<Informasi>? list_informasi,
    int? activePage,
    int? index,
    //int? activePage,
    //final int index;
  }){
    return InformasiPageChangeState(
        index: index?? this.index,
        //list_informasi: list_informasi ?? this.list_informasi,
        //activePage: activePage ?? this.activePage,
    );
  }

  //@override
  //String toString(){
  //  return InformasiPageChangeState(index: $this.index);
  //}

  //@override
  //List<Object?> get props => [activePage];
}

/*
class OneInformasiLoadedState extends InformasiState {
  final Informasi? informasi;
  OneInformasiLoadedState(list_informasi:const [],activePage:0,informasi:informasi);
  @override
  List<Object?> get props => [informasi];
}
*/
class InformasiErrorState extends InformasiState {
  final String error;
  InformasiErrorState(this.error):super(list_informasi:const [],activePage: 0);
  @override
  List<Object?> get props => [error];
}

/*
class InformasiState extends Equatable {
  const InformasiState({
    this.status = InformasiStatus.initial,
    List<Informasi>? informasi,
    int idSelected =0,
    int activePage =0,
        }): informasi = informasi ?? const [],
            idSelected = idSelected,
            activePage = activePage;

  final List<Informasi> informasi;
  final InformasiStatus status;
  final int idSelected;
  final int activePage;

  @override
  List<Object?> get props => [status,informasi,idSelected,activePage];

  InformasiState copyWith({
    List<Informasi>? informasi,
    InformasiStatus? status,
    int? idSelected,
    int? activePage,
  }){
    return InformasiState(
      informasi : informasi ?? this.informasi,
      status: status ?? this.status,
      idSelected: idSelected ?? this.idSelected,
      activePage: activePage ?? this.activePage,
    );
  }
  
}

 */
