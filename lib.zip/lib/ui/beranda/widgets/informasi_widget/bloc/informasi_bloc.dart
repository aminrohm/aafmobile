import 'dart:io';
import 'package:aafmobile/repositories/service/asiafmobile.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:aafmobile/repositories/models/informasi.dart';
//import 'package:aafmobile/repositories/asiafmobile_interface.dart';
import 'package:aafmobile/repositories/asiafmobile.dart';
import 'package:equatable/equatable.dart';

part 'informasi_event.dart';
part 'informasi_state.dart';


class InformasiBloc extends Bloc<InformasiEvent,InformasiState>{
  final AsiafMobileRepository asiafmobileRepository;
  int activePage;

  InformasiBloc({
    required activePage;
    required this.asiafmobileRepository,
}): super(InformasiLoadingState()){
    on<GetAllInformasi>(_mapGetAllInformasiEventToState);
    on<GetInformasiItem>(_mapGetInformasiItemEventToState);
    on<InformasiPageChange>(_mapInformasiPageChangeEventToState);
  }


  void _mapGetAllInformasiEventToState(
      GetAllInformasi event,Emitter<InformasiState> emit) async {
    emit(InformasiLoadingState());
    try{
      final list_informasi = await asiafmobileRepository.getAllInformasi();
      debugPrint("lagi diambil urlnya");
      print("informasi_bloc: $list_informasi");
      emit(AllInformasiLoadedState(list_informasi));
    }catch(error,stacktrace){
      debugPrint(stacktrace.toString());
      emit(InformasiErrorState(error.toString()));
    }
  }

  void _mapGetInformasiItemEventToState(
      GetInformasiItem Event,Emitter<InformasiState> emit) async {
    emit(InformasiLoadingState());
    try{
 //     final informasi_item = await asiafmobileRepository.getOne_informasi(Event.data);
  //    emit(OneInformasiLoadedState(informasi_item));
      //emit(state.copyWith(status: InformasiStatus.selected,),);
    }catch(error,stacktrace){
      debugPrint(stacktrace.toString());
      emit(InformasiErrorState(error.toString()));
    }
  }

  void _mapInformasiPageChangeEventToState(
      InformasiPageChange Event,
      Emitter<InformasiState> emit) async {
        try{
          final activePage = Event.data;
          emit(InformasiPageChangeState(activePage));
        }
        catch(error,stacktrace){
          debugPrint(stacktrace.toString());
          emit(InformasiErrorState(error.toString()));
        }
      }



}