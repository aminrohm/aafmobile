part of 'informasi_bloc.dart';

class InformasiEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class GetAllInformasiEvent extends InformasiEvent {
  //final List<Informasi> list_informasi;

  //GetAllInformasiEvent({
  //  required this.list_informasi,
//});

  @override
  List<Object?> get props => [];
}

class InformasiPageChangeEvent extends InformasiEvent {
  final int index;
  List<Informasi> list_informasi;

   InformasiPageChangeEvent({
    required this.index,
     required this.list_informasi,
  });
  @override
  List<Object?> get props => [index,list_informasi];

}

/*
class GetOneInformasiEvent extends InformasiEvent{
  final int data;
    GetOneInformasiEvent({
    required this.data,
  });

    @override
    List<Object?> get props => [data];

  }
*/




