part of 'informasi_bloc.dart';

class InformasiEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class GetAllInformasi extends InformasiEvent {}

class InformasiPageChange extends InformasiEvent {
  final int data;
  InformasiPageChange({
    required this.data,
  });
  @override
  List<Object?> get props => [data];

}


class GetInformasiItem extends InformasiEvent{
  final int data;
    GetInformasiItem({
    required this.data,
  });


    @override
    List<Object?> get props => [data];

  }




