part of 'informasi_detail_bloc.dart';

class InformasiDetailEvent extends Equatable {
  @override
  List<Object?> get props => [];
}


class GetInformasiDetailEvent extends InformasiDetailEvent{
  final int data;
    GetInformasiDetailEvent({
    required this.data,
  });

    @override
    List<Object?> get props => [data];

  }




