part of 'informasi_detail_bloc.dart';

/*
enum InformasiStatus {initial,success,error,loading}

extension InformasiStatusX on InformasiStatus {
  bool get isInitial => this => InformasiStatus.initial;
  bool get isSuccess => this => InformasiStatus.success;
  bool get isError => this => InformasiStatus.error;
  bool get isLoading => this => InformasiStatus.loading;
}

 */

@immutable
abstract class InformasiDetailStateX extends Equatable {}


class InformasiDetailState extends Equatable {
  InformasiDetailState();
  @override
  List<Object?> get props => [];
}

class InformasiDetailLoadingState extends InformasiDetailState {

  InformasiDetailLoadingState();
  @override
  List<Object?> get props => [];
}


class InformasiDetailLoadedState extends InformasiDetailState {
  final Informasi? informasi;

  InformasiDetailLoadedState({
    required this.informasi,
    });

  @override
  List<Object?> get props => [informasi];
}

class InformasiDetailErrorState extends InformasiDetailState {
  final String error;
  InformasiDetailErrorState(this.error);
  @override
  List<Object?> get props => [error];
}
