import 'package:flutter/material.dart';

class InformasiDetailPage extends StatelessWidget {
  const InformasiDetailPage({super.key});

  @override
  Widget build(BuildContext context){
    return Scaffold(
      //appBar: AppBar(
      //  title: const Text('Informasi Detail'),
      //),
      body:Center(
        child: ElevatedButton(
          child: const Text('Push me back'),
          onPressed: (){
            Navigator.pop(context);
          },
        ),
      ),
    );
  }
}