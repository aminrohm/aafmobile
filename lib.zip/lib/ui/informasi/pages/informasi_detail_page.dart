import 'package:flutter/material.dart';
import 'package:aafmobile/repositories/service/asiafmobile.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
//import 'package:aafmobile/repositories/models/informasi.dart';
import 'package:aafmobile/repositories/asiafmobile.dart';
//import 'package:equatable/equatable.dart';
//import 'package:aafmobile/ui/beranda/widgets/informasi_widget/bloc/informasi_bloc.dart';
import 'package:aafmobile/ui/informasi/widgets/bloc/informasi_detail_bloc.dart';
import 'package:aafmobile/ui/informasi/pages/informasi_detail_layout.dart';




class InformasiDetailPage extends StatelessWidget {
  //final InformasiBloc bloc;
  final int id;
  //const InformasiDetailPage({super.key});
  //const InformasiDetailPage({Key? key,required this.bloc,required this.id}):super(key:key);
  const InformasiDetailPage({Key? key,required this.id}):super(key:key);


  @override
  Widget build(BuildContext context){
    return Scaffold(
      body:RepositoryProvider(
        create: (context)=> AsiafMobileRepository(service: AsiafMobileService()),
        child: MultiBlocProvider(
          providers: [
            BlocProvider<InformasiDetailBloc>(
              create: (context) => InformasiDetailBloc(
              asiafmobileRepository: context.read<AsiafMobileRepository>(),
            )..add(GetInformasiDetailEvent(data: id)),
            ),
          ],
          child: InformasiDetailLayout(),
        ),
      ),
    );
  }


  }

