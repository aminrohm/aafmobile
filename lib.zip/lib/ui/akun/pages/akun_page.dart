import 'package:flutter/material.dart';

class AkunPage extends StatelessWidget {
  const AkunPage({super.key});

  @override
  Widget build(BuildContext context){
    return Scaffold(
      //appBar: AppBar(
      //  title: const Text('Akun'),
      //),
      body:Center(
        child: ElevatedButton(
          child: const Text('Push me back'),
          onPressed: (){
            Navigator.pop(context);
          },
        ),
      ),
    );
  }
}