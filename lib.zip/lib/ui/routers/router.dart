import 'package:flutter/material.dart';
import 'package:aafmobile/ui/routers/router.dart';
import 'package:aafmobile/ui/akun/pages/akun_page.dart';
import 'package:aafmobile/ui/beranda/pages/beranda_page.dart';
import 'package:aafmobile/ui/bantuan/pages/bantuan_page.dart';
import 'package:aafmobile/ui/promo/pages/promo_page.dart';
import 'package:go_router/go_router.dart';
import 'package:aafmobile/ui/beranda/pages/scaffold_nav.dart';
import 'package:aafmobile/ui/informasi/pages/informasi_detail_page.dart';
import 'package:aafmobile/ui/beranda/widgets/informasi_widget/bloc/informasi_bloc.dart';
import 'package:flutter_bloc/flutter_bloc.dart';


//import 'package:go_router_example/src/modules/details/details_page.dart';
//import 'package:go_router_example/src/modules/feed/feed_page.dart';
//import 'package:go_router_example/src/modules/scaffold_with_navbar/scaffold_with_navbar.dart';

// Create keys for `root` & `section` navigator avoiding unnecessary rebuilds
final _rootNavigatorKey = GlobalKey<NavigatorState>();
final _sectionNavigatorKey = GlobalKey<NavigatorState>();

final router = GoRouter(
  navigatorKey: _rootNavigatorKey,
  initialLocation: '/beranda',
  routes: <RouteBase>[
    StatefulShellRoute.indexedStack(
      builder: (context, state, navigationShell) {
        // Return the widget that implements the custom shell (e.g a BottomNavigationBar).
        // The [StatefulNavigationShell] is passed to be able to navigate to other branches in a stateful way.
        return ScaffoldNav(navigationShell);
      },
      branches: [
        // The route branch for the first Tab
        StatefulShellBranch(
          navigatorKey: _sectionNavigatorKey,
          // Add this branch routes
          // each routes with its sub routes if available e.g feed/uuid/details
          routes: <RouteBase>[
            GoRoute(
              name:'beranda',
              path: '/beranda',
              builder: (context, state) => const BerandaPage(),
              routes:<RouteBase>[
                GoRoute(
                  name: 'informasi-details',
                path: 'informasi-details/:id',
                builder: (context,state){
                    final id = state.pathParameters['id']!;
                    //final InformasiBloc infoBloc = state.extra! as InformasiBloc;
                    //final InformasiBloc infoBloc = BlocProvider.of<InformasiBloc>(context);
                    //return InformasiDetailPage(bloc:infoBloc,id: int.parse(id));
                    /*
                    return BlocProvider.value(
                      value: InformasiBloc,
                      child: InformasiDetailPage(id:int.parse(id)),
                    );*/
                  return InformasiDetailPage(
                    id: int.parse(id),
                  );


                },
                ),
              ],
            ),
          ],
        ),

        // The route branch for second Tab
        StatefulShellBranch(
            routes: <RouteBase>[
              // Add this branch routes
              // each routes with its sub routes if available e.g shope/uuid/details
              GoRoute(
                path: '/promo',
                builder: (context, state) {
                  return const PromoPage();
                },
              ),
            ]),

        // The route branch for third Tab
        StatefulShellBranch(
            routes: <RouteBase>[
              // Add this branch routes
              // each routes with its sub routes if available e.g shope/uuid/details
              GoRoute(
                path: '/akun',
                builder: (context, state) {
                  return const AkunPage();
                },
              ),
            ]),

        // The route branch for fourth Tab
        StatefulShellBranch(
            routes: <RouteBase>[
              // Add this branch routes
              // each routes with its sub routes if available e.g shope/uuid/details
              GoRoute(
                path: '/bantuan',
                builder: (context, state) {
                  return const BantuanPage();
                },
              ),
            ]),



      ],
    ),
  ],
);
