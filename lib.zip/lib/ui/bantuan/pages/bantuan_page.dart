import 'package:flutter/material.dart';

class BantuanPage extends StatelessWidget {
  const BantuanPage({super.key});

  @override
  Widget build(BuildContext context){
    return Scaffold(
      //appBar: AppBar(
      //  title: const Text('BANTUAN'),
      //),
      body:Center(
        child: ElevatedButton(
          child: const Text('Push me back'),
          onPressed: (){
            Navigator.pop(context);
          },
        ),
      ),
    );
  }
}