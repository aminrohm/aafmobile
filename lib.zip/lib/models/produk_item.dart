class ProdukItem{
  final int id;
  final String title;
  final int category;
  final String image_url;
  final String description;
  final double price;

  ProdukItem(this.id,this.title,this.category,this.image_url,this.description,this.price);

  ProdukItem.fromMap(Map<String,dynamic> data):
      id = data['id'],
      title = data['title'],
      category = data['category_id'],
      image_url = data['image_url'],
      description = data['description'],
      price = data['price'];

  Map<String,dynamic> toMap(){
        return {
          'id': id,
          'title' : title,
          'category': category,
          'image_url' : image_url,
          'description' : description,
          'price' : price
        };
      }


}