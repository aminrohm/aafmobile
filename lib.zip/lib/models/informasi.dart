class Informasi{
  final int id;
  final String title;
  final String image_url;
  final String description;


  Informasi(this.id,this.title,this.image_url,this.description);

  Informasi.fromMap(Map<String,dynamic> data):
      id = data['id'],
      title = data['title'],
      image_url = data['image_url'],
      description = data['description'];

  Map<String,dynamic> toMap(){
        return {
          'id': id,
          'title' : title,
          'image_url' : image_url,
          'description' : description
        };
      }

  Informasi.fromJson(Map<String,dynamic> json):
    id = json['id'],
    title = json['title'],
    image_url = json['image_url'],
    description = json['description'];

  Map<String,dynamic> toJson(){
    return {
      'id': id,
      'title' : title,
      'image_url' : image_url,
      'description' : description
    };
  }

}