import 'package:flutter/material.dart';

/// Flutter code sample for [BottomNavigationBar].

List<String> images = [
  "https://images.bisnis.com/posts/2021/12/14/1477432/toyota-rush1.jpg",
  "https://pict.sindonews.net/dyn/732/pena/news/2022/08/27/120/867877/4-mobil-mewah-kurang-laku-di-pasaran-indonesia-ada-toyota-alphard-not.jpeg",
  "https://tsoimageprod.azureedge.net/sys-master-hybrismedia/h38/hfa/8821108506654/mobil-kecil-untuk-4-orang.jpg"
];

void main() => runApp(const BottomNavigationBarExampleApp());

class BottomNavigationBarExampleApp extends StatelessWidget {
  const BottomNavigationBarExampleApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: BottomNavigationBarExample(),
    );
  }
}

class BottomNavigationBarExample extends StatefulWidget {
  const BottomNavigationBarExample({super.key});

  @override
  State<BottomNavigationBarExample> createState() =>
      _BottomNavigationBarExampleState();
}

class _BottomNavigationBarExampleState
    extends State<BottomNavigationBarExample> {
  int _selectedIndex = 0;
  int activePage = 1;
  static const TextStyle optionStyle =
  TextStyle(fontSize: 30, fontWeight: FontWeight.bold);
  static const List<Widget> _widgetOptions = <Widget>[
    Text(
      'Index 0: Home',
      style: optionStyle,
    ),
    Text(
      'Index 1: Promo',
      style: optionStyle,
    ),
    Text(
      'Index 2: Akun',
      style: optionStyle,
    ),
    Text(
      'index 3: Bantuan',
      style: optionStyle,
    ),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Asiaf Mobile'),
        backgroundColor: Colors.red,
      ),
      body: Center(
        //child: _widgetOptions.elementAt(_selectedIndex),
        child: Column(
          children: <Widget>[
            Text("Informasi",style: const TextStyle(fontSize:20,fontWeight: FontWeight.bold),),
            Expanded(
              flex: 5,
              child:Column(
                children: <Widget>[
                  SizedBox(
                    height:300,
                    child:PageView.builder(
                      itemCount: images.length,
                      pageSnapping: true,
                      onPageChanged: (page){
                      setState(() {
                        activePage = page;
                      });
                    },
                    itemBuilder: (context,pagePosition){
                      return Container(
                        margin: EdgeInsets.all(10),
                        child: Image.network(images[pagePosition],fit:BoxFit.cover,),
                        );
                      },
                    ),
                  ),
                    Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: indicators(images.length,activePage)
                      ),
                  //Text("aaaa bbbb"),
                      ],
            ),
            ),
            Expanded(
              flex: 3,
              child: Column(
                children: <Widget>[
                  Text("Katagori Produk",style: const TextStyle(fontSize:20,fontWeight: FontWeight.bold),),
                  Container(
                    height:150,
                    child:GridView.count(
                      primary: false,
                      padding: const EdgeInsets.all(20),
                      crossAxisCount: 3,
                      crossAxisSpacing: 10,
                      mainAxisSpacing: 10,
                      children: catagory_buttons(images.length),
                    ),
                  ),
                  ],
              ),
              ),
            Expanded(
              flex: 2,
              child: Container(
                //color: Colors.greenAccent,
                height: 80,
                child: Column(
                  children: <Widget>[
                    Text("Manajemen Kontrak",style: const TextStyle(fontSize:20,fontWeight: FontWeight.bold),),
                    Spacer(),
                    Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children:<Widget>[
                    ClipRRect(
                      borderRadius: BorderRadius.circular(70),
                      child: Material(
                        color: Colors.amberAccent,
                        child: SizedBox(
                          width:80,
                          height:80,
                          child: InkWell(
                          splashColor: Colors.greenAccent,
                          onTap: (){},
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Icon(Icons.feed_outlined),
                              Text("Kontrak"),
                          ],
                      ),
                    ),
                        ),
                      ),
                    ),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(70),
                      child: Material(
                        color:Colors.amberAccent,
                        child: SizedBox(
                          width: 80,
                          height: 80,
                          child: InkWell(
                          splashColor: Colors.greenAccent,
                          onTap: (){},
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Icon(Icons.payments),
                              Text("Bayar"),
                            ],
                          ),
                        ),
                        ),
                      ),
                    ),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(70),
                      child: Material(
                        color:Colors.amberAccent,
                        child: SizedBox(
                          width: 80,
                          height: 80,
                          child:InkWell(
                          splashColor: Colors.greenAccent,
                          onTap: (){},
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Icon(Icons.work_history),
                              Text("Riwayat"),
                            ],
                          ),
                        ),
                        ),
                      ),
                    ),
                  ]
                ),
                    Spacer(),
                ],
                ),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        type:BottomNavigationBarType.fixed,
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Beranda',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.star),
            label: 'Promo',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.account_box),
            label: 'Akun',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.question_mark),
            label: 'Bantuan',
          ),
        ],
        currentIndex: _selectedIndex,
        backgroundColor: Colors.red,
        selectedItemColor: Colors.white,
        onTap: _onItemTapped,
      ),
    );
  }
}

List<Widget> indicators(imagesLength,currentIndex) {
  return List<Widget>.generate(imagesLength, (index) {
    return Container(
      margin: EdgeInsets.all(3),
      width: 10,
      height: 10,
      decoration: BoxDecoration(
          color: currentIndex == index ? Colors.black : Colors.black26,
          shape: BoxShape.circle),
    );
  });
}


List<Widget> catagory_buttons(imagesLength) {
  return List<Widget>.generate(imagesLength, (index) {
    return GestureDetector(
      onTap: (){
        debugPrint("i am tapped");
      },
      child: Ink.image(
          image: NetworkImage(images[index]),
          height : 30,
          fit: BoxFit.cover,
          child:Text('Mobil Niaga'),
      ),
    );
  });
}