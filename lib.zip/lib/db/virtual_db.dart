import 'dart:math';

import 'package:aafmobile/models/category.dart';
import 'package:aafmobile/models/informasi.dart';
import 'package:aafmobile/models/produk_item.dart';

class VirtualDB{
  List<Map<Category, dynamic>> _items_category = [];
  List<Map<String, dynamic>> _items_informasi = [
  {'id':1,'title':'title1','image_url':'https://images.bisnis.com/posts/2021/12/14/1477432/toyota-rush1.jpg','description':'description1'},
  {'id':2,'title':'title2','image_url':'https://pict.sindonews.net/dyn/732/pena/news/2022/08/27/120/867877/4-mobil-mewah-kurang-laku-di-pasaran-indonesia-ada-toyota-alphard-not.jpeg','description':'description2'},
  {'id':3,'title':'title3','image_url':'https://tsoimageprod.azureedge.net/sys-master-hybrismedia/h38/hfa/8821108506654/mobil-kecil-untuk-4-orang.jpg','description':'description3'},
  ];
  List<Map<ProdukItem, dynamic>> _items_produkitem = [];

  static final VirtualDB _db = VirtualDB._privateConstructor();

  VirtualDB._privateConstructor();

  factory VirtualDB(){
    return _db;
  }

  // INSERT
  /*
  Future<void> insert_category(Map<String,dynamic> item) async {
    item['id'] = random().nextInt(1000);
    _items_category.add(item);
  }

  Future<void> insert_informasi(Map<String,dynamic> item) async {
    item['id'] = random().nextInt(1000);
    _items_informasi.add(item);
  }

  Future<void> insert_produkitem(Map<String,dynamic> item) async {
    item['id'] = random().nextInt(1000);
    _items_produkitem.add(item);
  }

   */

  // REMOVE
  /*
  Future<void> remove_category(int id) async {
    _items_category.removeWhere((item) => item['id'] == id);
  }

  Future<void> remove_informasi(int id) async {
    _items_informasi.removeWhere((item) => item['id'] == id);
  }

  Future<void> remove_produkitem(int id) async {
    _items_produkitem.removeWhere((item) => item['id'] == id);
  }

   */

  //UPDATE
  /*
  Future<void> update_category(Map<String, dynamic> updatedItem) async {
    int i = _items_category.indexWhere((item) => item['id'] == updatedItem['id']);
    _items_category[i] = updatedItem;
  }

  Future<void> update_informasi(Map<String, dynamic> updatedItem) async {
    int i = _items_informasi.indexWhere((item) => item['id'] == updatedItem['id']);
    _items_informasi[i] = updatedItem;
  }

  Future<void> update_produkitem(Map<String, dynamic> updatedItem) async {
    int i = _items_produkitem.indexWhere((item) => item['id'] == updatedItem['id']);
    _items_produkitem[i] = updatedItem;
  }

   */

  //LIST
  Future<List<Map<String, dynamic>>> list_informasi() async {
    await Future.delayed(Duration(milliseconds: 800));
    return _items_informasi;
  }

/*
  Future<List<Map<String, dynamic>>> list_category() async {
    await Future.delayed(Duration(milliseconds: 800));
    return _items_category;
  }


  Future<List<Map<String, dynamic>>> list_produkitem() async {
    await Future.delayed(Duration(milliseconds: 800));
    return _items_produkitem;
  }

 */

  //GetOne
  /*
  Future<Map<String,dynamic>?> getOne_category(int id) async{
    return _items_category.firstWhere((item) => item['id']==id);
  }

  Future<Map<String,dynamic>?> getOne_informasi(int id) async{
    return _items_informasi.firstWhere((item) => item['id']==id);
  }

  Future<Map<String,dynamic>?> getOne_produkitem(int id) async{
    return _items_produkitem.firstWhere((item) => item['id']==id);
  }

   */


}