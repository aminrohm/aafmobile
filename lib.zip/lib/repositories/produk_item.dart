import 'package:aafmobile/db/virtual_db.dart';
import 'package:aafmobile/repositories/produkitem_interface.dart';
import 'package:aafmobile/models/produk_item.dart';

class ProdukItemRepository implements ProdukItemRepository{

  final VirtualDB _db;
  ProdukItemRepository(this._db);

  @override
  Future<List<ProdukItem>> getAll_produkitem() async {
    var items = await _db.list_produkitem();
    return items.map((item)=> ProdukItem.fromMap(item)).toList();
  }

  @override
  Future<ProdukItem?> getOne_produkitem(int id) async {
    var item = await _db.getOne_produkitem(id);
    return item != null ? ProdukItem.fromMap(item):null;
  }

  @override
  Future<void> insert_produkitem(ProdukItem produkItem) async {
    await _db.insert_produkitem(produkItem.toMap());
  }

  @override
  Future<void> delete_produkitem(int id) async {
    await _db.remove_produkitem(id);
  }

}