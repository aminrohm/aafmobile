
class Image {
    final String picture;

    Image(this.image);

    Image.fromMap(Map<String,dynamic> data):
        picture = data['picture'];

    Map<String,dynamic> toMap(){
        return {
            'picture': picture
        }
    }

    Image.fromJson(Map<String,dynamic> data):
        picture = data['picture'];

    Map<String,dynamic> toJson(){
        return {
            'picture': picture
        }
    }

}

class Category{
    final int id;
    final List<Image> rep_image;
    final String name;
    final int classification_id;

    Category(this.name);

    Category.fromMap(Map<String,dynamic> data):
            id = data['id'],
            rep_image = data['rep_image'],
            name = data['name'],
            classification_id = data['classification'];


    Map<String,dynamic> toMap(){
        return {
          'id': id,
          'rep_image': rep_image,
          'name' : name,
          'classification' : classification_id
        };
      } 

    Category.fromJson(Map<String,dynamic> data):
            id = data['id'],
            rep_image = data['rep_image'],
            name = data['name'],
            classification_id = data['classification'];


    Map<String,dynamic> toJson(){
        return {
          'id': id,
          'rep_image': rep_image,
          'name' : name,
          'classification' : classification_id
        };
      } 



}

class Brand{
    final String name;

    Brand(this.name);

    Brand.fromMap(Map<String,dynamic> data):
            name = data['name'];


    Map<String,dynamic> toMap(){
        return {
          'name': name
        };
      } 

    Brand.fromJson(Map<String,dynamic> data):
            name = data['name'];


    Map<String,dynamic> toJson(){
        return {
          'name': name
        };
      } 


}

class Specification{
    final int id;
    final Transmisi transmisi;
    final BahanBakar bahanbakar;
    final int manufacturing_year;
    final String kilometer;
    final int konsumsi_bbm;
    final int torsi;
    final int kapasitas_mesin;
    final int kapasitas_penumpang;
    final String dimensi;
    final String deskripsi;


    Specification(this.id,
                  this.transmisi,
                  this.bahanbakar,
                  this.manufacturing_year,
                  this.kilometer,
                  this.konsumsi_bbm,
                  this.torsi,
                  this.kapasitas_mesin,
                  this.kapasitas_penumpang,
                  this.dimensi,
                  this.deskripsi);

    Specification.fromMap(Map<String,dynamic> data):
            id = data['id'],
            transmisi = data['transmisi'],
            bahanbakar = data['bahanbakar'],
            manufacturing_year = data['manufacturing_year'],
            kilometer = data['kilometer'],
            konsumsi_bbm= data['konsumsi_bbm'],
            torsi = data['torsi'],
            kapasitas_mesin = data['kapasitas_mesin'],
            kapasitas_penumpang = data['kapasitas_penumpang'],
            dimensi = data['dimensi'],
            deskripsi = data['deskripsi'];

    Map<String,dynamic> toMap(){
        return {
          'id': id,
          'transmisi' : transmisi,
          'bahanbakar' : bahanbakar,
          'manufacturing_year' : manufacturing_year,
          'kilometer': kilometer,
          'konsumsi_bbm':konsumsi_bbm,
          'torsi' : torsi,
          'kapasitas_mesin': kapasitas_mesin,
          'kapasitas_penumpang': kapasitas_penumpang,
          'dimensi': dimensi,
          'deskripsi': deskripsi
        };
      } 

    Specification.fromJson(Map<String,dynamic> data):
            id = data['id'],
            transmisi = data['transmisi'],
            bahanbakar = data['bahanbakar'],
            manufacturing_year = data['manufacturing_year'],
            kilometer = data['kilometer'],
            konsumsi_bbm= data['konsumsi_bbm'],
            torsi = data['torsi'],
            kapasitas_mesin = data['kapasitas_mesin'],
            kapasitas_penumpang = data['kapasitas_penumpang'],
            dimensi = data['dimensi'],
            deskripsi = data['deskripsi'];

    Map<String,dynamic> toJson(){
        return {
          'id': id,
          'transmisi' : transmisi,
          'bahanbakar' : bahanbakar,
          'manufacturing_year' : manufacturing_year,
          'kilometer': kilometer,
          'konsumsi_bbm':konsumsi_bbm,
          'torsi' : torsi,
          'kapasitas_mesin': kapasitas_mesin,
          'kapasitas_penumpang': kapasitas_penumpang,
          'dimensi': dimensi,
          'deskripsi': deskripsi
        };
      } 





}

class Product{
    final int id;
    final String name;
    final List<Image> image;
    final Category category;
    final Brand brand;
    final Specification specification;
    final int harga_otr;

    Product(this.id,
            this.name,
            this.image,
            this.category,
            this.brand,
            this.specification,
            this.harga_otr);

    Product.fromMap(Map<String,dynamic> data):
            id = data['id'],
            name = data['name'],
            image = data['image'],
            category = data['category'],
            brand = data['brand'],
            specification= data['specification'],
            harga_otr = data['harga_otr'];

    Map<String,dynamic> toMap(){
        return {
          'id': id,
          'name' : name,
          'image' : image,
          'category' : category,
          'brand': brand,
          'specification':specification,
          'harga_otr' : harga_otr
        };
      } 

    Product.fromJson(Map<String,dynamic> data):
            id = data['id'],
            name = data['name'],
            image = data['image'],
            category = data['category'],
            brand = data['brand'],
            specification= data['specification'],
            harga_otr = data['harga_otr'];

    Map<String,dynamic> toJson(){
        return {
          'id': id,
          'name' : name,
          'image' : image,
          'category' : category,
          'brand': brand,
          'specification':specification,
          'harga_otr' : harga_otr
        };
      } 



}