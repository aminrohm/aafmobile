import 'package:aafmobile/models/category.dart';

abstract class CategoryRepository {
  Future<List<Category>> getAll();
  Future<Category?> getOne_category(int id);
  Future<void> insert_category(Category category);
  Future<void> update_category(Category category);
  Future<void> delete_category(int id);
}