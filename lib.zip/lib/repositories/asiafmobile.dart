import 'package:aafmobile/db/virtual_db.dart';
//import 'package:aafmobile/repositories/informasi_interface.dart';
import 'package:aafmobile/repositories/models/informasi.dart';
//import 'package:aafmobile/models/category.dart';
//import 'package:aafmobile/models/produk_item.dart';
import 'package:http/http.dart';
import 'dart:convert';
import 'package:aafmobile/repositories/service/asiafmobile.dart';

//class AsiafMobileRepository implements AsiafMobileRepository{
class AsiafMobileRepository{
  //final VirtualDB _db;

  //AsiafMobileRepository(this._db);
  const AsiafMobileRepository({
    required this.service,
});
  final AsiafMobileService service;

  Future<List<Informasi>> getAllInformasi() async => service.getAllInformasi();

  Future<Informasi?> getInformasiDetail(int id) async {
    //var item = await _db.getOne_informasi(id);
    var item = service.getInformasiDetail(id);
    //return item != null ? Informasi.fromMap(item):null;
    return item != null ? item:null;
  }


  //@override
  //Future<List<Informasi>> getAll_informasi() async {
  //  var items = await _db.list_informasi();
  //  return items.map((item)=> Informasi.fromMap(item)).toList();
  //}
/*
  Future<List<Informasi>> getAll_informasi_from_url() async {
    Response response = await get(Uri.parse("http://192.168.50.38:8080/informasi"));
    //print("ini response");
    //print(response.body);
    //print("ini response status code");
    //print(response.statusCode);
    if(response.statusCode == 200){
      //final List result = jsonDecode(response.body)['data'];
      final List result = jsonDecode(response.body);
      //print("ini result");
      //print(result);
      return result.map((e) => Informasi.fromJson(e)).toList();
    } else{
      throw Exception(response.reasonPhrase);
    }

  }

 */
  /*
  @override
  Future<Informasi?> getOne_informasi(int id) async {
    var item = await _db.getOne_informasi(id);
    return item != null ? Informasi.fromMap(item):null;
  }

  @override
  Future<void> insert_informasi(Informasi informasi) async {
    await _db.insert_informasi(informasi.toMap());
  }

  @override
  Future<void> delete_informasi(int id) async {
    await _db.remove_informasi(id);
  }

  //Category
  @override
  Future<List<Category>> getAll_category() async {
    var items = await _db.list_category();
    return items.map((item)=> Category.fromMap(item)).toList();
  }

  @override
  Future<Category?> getOne_category(int id) async {
    var item = await _db.getOne_category(id);
    return item != null ? Category.fromMap(item):null;
  }

  @override
  Future<void> insert_category(Category category) async {
    await _db.insert_category(category.toMap());
  }

  @override
  Future<void> delete_category(int id) async {
    await _db.remove_category(id);
  }
  // Produk Item
  @override
  Future<List<ProdukItem>> getAll_produkitem() async {
    var items = await _db.list_produkitem();
    return items.map((item)=> ProdukItem.fromMap(item)).toList();
  }

  @override
  Future<ProdukItem?> getOne_produkitem(int id) async {
    var item = await _db.getOne_produkitem(id);
    return item != null ? ProdukItem.fromMap(item):null;
  }

  @override
  Future<void> insert_produkitem(ProdukItem produkItem) async {
    await _db.insert_category(produkItem.toMap());
  }

  @override
  Future<void> delete_produkitem(int id) async {
    await _db.remove_produkitem(id);
  }

   */

}