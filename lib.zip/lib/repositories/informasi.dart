import 'package:aafmobile/db/virtual_db.dart';
import 'package:aafmobile/repositories/informasi_interface.dart';
import 'package:aafmobile/models/informasi.dart';

class InformasiRepository implements InformasiRepository{

  final VirtualDB _db;
  InformasiRepository(this._db);

  @override
  Future<List<Informasi>> getAll_informasi() async {
    var items = await _db.list_informasi();
    return items.map((item)=> Informasi.fromMap(item)).toList();
  }

  @override
  Future<Informasi?> getOne_informasi(int id) async {
    var item = await _db.getOne_informasi(id);
    return item != null ? Informasi.fromMap(item):null;
  }

  @override
  Future<void> insert_informasi(Informasi informasi) async {
    await _db.insert_informasi(informasi.toMap());
  }

  @override
  Future<void> delete_informasi(int id) async {
    await _db.remove_informasi(id);
  }

}