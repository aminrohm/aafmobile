import 'package:aafmobile/models/produk_item.dart';

abstract class ProdukItemRepository {
  Future<List<ProdukItem>> getAll();
  Future<ProdukItem?> getOne(int id);
  Future<void> insert(ProdukItem produkItem);
  Future<void> update(ProdukItem produkItem);
  Future<void> delete(int id);
}