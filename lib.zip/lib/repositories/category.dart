import 'package:aafmobile/db/virtual_db.dart';
import 'package:aafmobile/repositories/category_interface.dart';
import 'package:aafmobile/models/category.dart';

class CategoryRepository implements CategoryRepository{

  final VirtualDB _db;
  CategoryRepository(this._db);

  @override
  Future<List<Category>> getAll_category() async {
    var items = await _db.list_category();
    return items.map((item)=> Category.fromMap(item)).toList();
  }

  @override
  Future<Category?> getOne_category(int id) async {
    var item = await _db.getOne_category(id);
    return item != null ? Category.fromMap(item):null;
  }

  @override
  Future<void> insert_category(Category category) async {
    await _db.insert_category(category.toMap());
  }

  @override
  Future<void> delete_category(int id) async {
    await _db.remove_category(id);
  }

}