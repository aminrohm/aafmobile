import 'dart:convert';
import './informasi.dart';
import './common.dart';
import 'dart:async';
import 'package:http/http.dart' as http;


void main() async {




var apiUrl = Uri.http('192.168.0.106:8080','/info/');

//final String apiUrl ='http://192.168.0.106:8080/prod-by-spec/2';

final http.Response response = await http.get(apiUrl);

if (response.statusCode == 200)
{


List<dynamic> infos = jsonDecode(response.body);



List<Information> info_list=[];



for (var info in infos){
    List<Image> info_image_list =[];
    for (var image in info['images']){
      info_image_list.add(Image.fromMap(image));
    }
    print(info_image_list[0].url);


    info_list.add(Information(
      info['id'],
      info['title'],
      info_image_list,
      info['contents']
    ));

  }

  for (var info in info_list){
      print(info.title);
      for (var image in info.images){
        print(image.url);
      }
  }

}

}
