import 'dart:convert';
import './product.dart';
import 'dart:async';
import 'package:http/http.dart' as http;


void main() async {


  String jsonStr = """
  {"data":[
    {
        "id": 311,
        "name": "Komatsu UIE986",
        "image": [
            {
                "picture": "/home/ayuhana/django/asiafmobile/imagex/p_lamorgini.jpg"
            },
            {
                "picture": "/home/ayuhana/django/asiafmobile/imagex/c2_mobilbox_freezer.jpg"
            },
            {
                "picture": "/home/ayuhana/django/asiafmobile/imagex/c2ch.jpg"
            }
        ],
        "category": {
            "id": 1,
            "rep_image": [
                {
                    "picture": "/home/ayuhana/django/asiafmobile/imagex/lamorgini.jpg"
                }
            ],
            "name": "Combine",
            "classification": 1
        },
        "brand": {
            "name": "KAWASAKI"
        },
        "specification": {
            "id": 311,
            "transmisi": {
                "name": "Manual"
            },
            "bahan_bakar": {
                "name": "Bensin"
            },
            "manufacturing_year": 2020,
            "kilometer": "511",
            "konsumsi_bbm": 142,
            "torsi": 73,
            "kapasitas_mesin": 1131,
            "kapasitas_penumpang": 98,
            "dimensi": "10mx20m",
            "deskripsi": "Question may finally nice may process conference item. Card the couple contain. Then Republican study develop one compare region miss."
        },
        "harga_otr": 254699793
    },
    {
        "id": 321,
        "name": "MITSUBISHI UIE280",
        "image": [
            {
                "picture": "/home/ayuhana/django/asiafmobile/imagex/c2_microbus.jpg"
            },
            {
                "picture": "/home/ayuhana/django/asiafmobile/imagex/c2_dumptruck.jpg"
            },
            {
                "picture": "/home/ayuhana/django/asiafmobile/imagex/p_crv.jpg"
            }
        ],
        "category": {
            "id": 1,
            "rep_image": [
                {
                    "picture": "/home/ayuhana/django/asiafmobile/imagex/lamorgini.jpg"
                }
            ],
            "name": "Combine",
            "classification": 1
        },
        "brand": {
            "name": "NISSAN"
        },
        "specification": {
            "id": 321,
            "transmisi": {
                "name": "Automatic"
            },
            "bahan_bakar": {
                "name": "Bensin"
            },
            "manufacturing_year": 2016,
            "kilometer": "624",
            "konsumsi_bbm": 163,
            "torsi": 91,
            "kapasitas_mesin": 746,
            "kapasitas_penumpang": 82,
            "dimensi": "5mx5m",
            "deskripsi": "Under smile evening explain. Require forget true improve travel health seem. Material cell from bed art shoulder. Personal picture parent want. Most yourself arrive report discuss song fight call. Office cultural serious family."
        },
        "harga_otr": 675351383
    },
    {
        "id": 340,
        "name": "CHEVROLET UIE546",
        "image": [
            {
                "picture": "/home/ayuhana/django/asiafmobile/imagex/c2_mobilbox_freezer.jpg"
            },
            {
                "picture": "/home/ayuhana/django/asiafmobile/imagex/c1a.jpg"
            },
            {
                "picture": "/home/ayuhana/django/asiafmobile/imagex/c3_headtractor.png"
            }
        ],
        "category": {
            "id": 1,
            "rep_image": [
                {
                    "picture": "/home/ayuhana/django/asiafmobile/imagex/lamorgini.jpg"
                }
            ],
            "name": "Combine",
            "classification": 1
        },
        "brand": {
            "name": "MAZDA"
        },
        "specification": {
            "id": 340,
            "transmisi": {
                "name": "Automatic"
            },
            "bahan_bakar": {
                "name": "Avtur"
            },
            "manufacturing_year": 2019,
            "kilometer": "551",
            "konsumsi_bbm": 145,
            "torsi": 71,
            "kapasitas_mesin": 1902,
            "kapasitas_penumpang": 36,
            "dimensi": "30mx20m",
            "deskripsi": "Fish police sport and record tree simple. School tell doctor TV bank garden assume. Newspaper material him why against."
        },
        "harga_otr": 790356902
    },
    {
        "id": 385,
        "name": "MAZDA XYZ855",
        "image": [
            {
                "picture": "/home/ayuhana/django/asiafmobile/imagex/c3h.jpg"
            },
            {
                "picture": "/home/ayuhana/django/asiafmobile/imagex/c1b.jpg"
            },
            {
                "picture": "/home/ayuhana/django/asiafmobile/imagex/c2bi.jpg"
            }
        ],
        "category": {
            "id": 1,
            "rep_image": [
                {
                    "picture": "/home/ayuhana/django/asiafmobile/imagex/lamorgini.jpg"
                }
            ],
            "name": "Combine",
            "classification": 1
        },
        "brand": {
            "name": "MITSUBISHI"
        },
        "specification": {
            "id": 385,
            "transmisi": {
                "name": "Manual"
            },
            "bahan_bakar": {
                "name": "Avtur"
            },
            "manufacturing_year": 2019,
            "kilometer": "597",
            "konsumsi_bbm": 144,
            "torsi": 75,
            "kapasitas_mesin": 653,
            "kapasitas_penumpang": 95,
            "dimensi": "30mx20m",
            "deskripsi": "Service education put key real least. Become stay father late upon. Push police too cost. Compare rate suggest teach method enter. Keep identify commercial quality politics. Entire per night fight nor until both."
        },
        "harga_otr": 722095933
    },
    {
        "id": 393,
        "name": "YAMAHA ABC134",
        "image": [
            {
                "picture": "/home/ayuhana/django/asiafmobile/imagex/c3i.jpg"
            },
            {
                "picture": "/home/ayuhana/django/asiafmobile/imagex/c2_mobilbox.jpg"
            },
            {
                "picture": "/home/ayuhana/django/asiafmobile/imagex/c2i.jpg"
            }
        ],
        "category": {
            "id": 1,
            "rep_image": [
                {
                    "picture": "/home/ayuhana/django/asiafmobile/imagex/lamorgini.jpg"
                }
            ],
            "name": "Combine",
            "classification": 1
        },
        "brand": {
            "name": "FORD"
        },
        "specification": {
            "id": 393,
            "transmisi": {
                "name": "Manual"
            },
            "bahan_bakar": {
                "name": "Bensin"
            },
            "manufacturing_year": 2021,
            "kilometer": "292",
            "konsumsi_bbm": 113,
            "torsi": 25,
            "kapasitas_mesin": 993,
            "kapasitas_penumpang": 98,
            "dimensi": "5mx5m",
            "deskripsi": "Measure physical establish improve after important. Head near trade catch start. Really financial international probably share for. Wonder allow bag talk say break sometimes. Best join eight."
        },
        "harga_otr": 1821767526
    },
    {
        "id": 400,
        "name": "KIA ABC852",
        "image": [
            {
                "picture": "/home/ayuhana/django/asiafmobile/imagex/c2_mobilbox_freezer.jpg"
            },
            {
                "picture": "/home/ayuhana/django/asiafmobile/imagex/c1a.jpg"
            },
            {
                "picture": "/home/ayuhana/django/asiafmobile/imagex/c3bm.jpg"
            }
        ],
        "category": {
            "id": 1,
            "rep_image": [
                {
                    "picture": "/home/ayuhana/django/asiafmobile/imagex/lamorgini.jpg"
                }
            ],
            "name": "Combine",
            "classification": 1
        },
        "brand": {
            "name": "AUDI"
        },
        "specification": {
            "id": 400,
            "transmisi": {
                "name": "Automatic"
            },
            "bahan_bakar": {
                "name": "Avtur"
            },
            "manufacturing_year": 2015,
            "kilometer": "328",
            "konsumsi_bbm": 155,
            "torsi": 14,
            "kapasitas_mesin": 699,
            "kapasitas_penumpang": 99,
            "dimensi": "30mx20m",
            "deskripsi": "Pm evening meet common his. Significant star throughout laugh draw outside miss. Sort move president method analysis life. Save country always music mission dog."
        },
        "harga_otr": 928252182
    }]
}
""";
  
  String jsonLst = """
  [
    {
        "id": 311,
        "name": "Komatsu UIE986",
        "image": [
            {
                "picture": "/home/ayuhana/django/asiafmobile/imagex/p_lamorgini.jpg"
            },
            {
                "picture": "/home/ayuhana/django/asiafmobile/imagex/c2_mobilbox_freezer.jpg"
            },
            {
                "picture": "/home/ayuhana/django/asiafmobile/imagex/c2ch.jpg"
            }
        ],
        "category": {
            "id": 1,
            "rep_image": [
                {
                    "picture": "/home/ayuhana/django/asiafmobile/imagex/lamorgini.jpg"
                }
            ],
            "name": "Combine",
            "classification": 1
        },
        "brand": {
            "name": "KAWASAKI"
        },
        "specification": {
            "id": 311,
            "transmisi": {
                "name": "Manual"
            },
            "bahan_bakar": {
                "name": "Bensin"
            },
            "manufacturing_year": 2020,
            "kilometer": "511",
            "konsumsi_bbm": 142,
            "torsi": 73,
            "kapasitas_mesin": 1131,
            "kapasitas_penumpang": 98,
            "dimensi": "10mx20m",
            "deskripsi": "Question may finally nice may process conference item. Card the couple contain. Then Republican study develop one compare region miss."
        },
        "harga_otr": 254699793
    },
    {
        "id": 321,
        "name": "MITSUBISHI UIE280",
        "image": [
            {
                "picture": "/home/ayuhana/django/asiafmobile/imagex/c2_microbus.jpg"
            },
            {
                "picture": "/home/ayuhana/django/asiafmobile/imagex/c2_dumptruck.jpg"
            },
            {
                "picture": "/home/ayuhana/django/asiafmobile/imagex/p_crv.jpg"
            }
        ],
        "category": {
            "id": 1,
            "rep_image": [
                {
                    "picture": "/home/ayuhana/django/asiafmobile/imagex/lamorgini.jpg"
                }
            ],
            "name": "Combine",
            "classification": 1
        },
        "brand": {
            "name": "NISSAN"
        },
        "specification": {
            "id": 321,
            "transmisi": {
                "name": "Automatic"
            },
            "bahan_bakar": {
                "name": "Bensin"
            },
            "manufacturing_year": 2016,
            "kilometer": "624",
            "konsumsi_bbm": 163,
            "torsi": 91,
            "kapasitas_mesin": 746,
            "kapasitas_penumpang": 82,
            "dimensi": "5mx5m",
            "deskripsi": "Under smile evening explain. Require forget true improve travel health seem. Material cell from bed art shoulder. Personal picture parent want. Most yourself arrive report discuss song fight call. Office cultural serious family."
        },
        "harga_otr": 675351383
    },
    {
        "id": 340,
        "name": "CHEVROLET UIE546",
        "image": [
            {
                "picture": "/home/ayuhana/django/asiafmobile/imagex/c2_mobilbox_freezer.jpg"
            },
            {
                "picture": "/home/ayuhana/django/asiafmobile/imagex/c1a.jpg"
            },
            {
                "picture": "/home/ayuhana/django/asiafmobile/imagex/c3_headtractor.png"
            }
        ],
        "category": {
            "id": 1,
            "rep_image": [
                {
                    "picture": "/home/ayuhana/django/asiafmobile/imagex/lamorgini.jpg"
                }
            ],
            "name": "Combine",
            "classification": 1
        },
        "brand": {
            "name": "MAZDA"
        },
        "specification": {
            "id": 340,
            "transmisi": {
                "name": "Automatic"
            },
            "bahan_bakar": {
                "name": "Avtur"
            },
            "manufacturing_year": 2019,
            "kilometer": "551",
            "konsumsi_bbm": 145,
            "torsi": 71,
            "kapasitas_mesin": 1902,
            "kapasitas_penumpang": 36,
            "dimensi": "30mx20m",
            "deskripsi": "Fish police sport and record tree simple. School tell doctor TV bank garden assume. Newspaper material him why against."
        },
        "harga_otr": 790356902
    },
    {
        "id": 385,
        "name": "MAZDA XYZ855",
        "image": [
            {
                "picture": "/home/ayuhana/django/asiafmobile/imagex/c3h.jpg"
            },
            {
                "picture": "/home/ayuhana/django/asiafmobile/imagex/c1b.jpg"
            },
            {
                "picture": "/home/ayuhana/django/asiafmobile/imagex/c2bi.jpg"
            }
        ],
        "category": {
            "id": 1,
            "rep_image": [
                {
                    "picture": "/home/ayuhana/django/asiafmobile/imagex/lamorgini.jpg"
                }
            ],
            "name": "Combine",
            "classification": 1
        },
        "brand": {
            "name": "MITSUBISHI"
        },
        "specification": {
            "id": 385,
            "transmisi": {
                "name": "Manual"
            },
            "bahan_bakar": {
                "name": "Avtur"
            },
            "manufacturing_year": 2019,
            "kilometer": "597",
            "konsumsi_bbm": 144,
            "torsi": 75,
            "kapasitas_mesin": 653,
            "kapasitas_penumpang": 95,
            "dimensi": "30mx20m",
            "deskripsi": "Service education put key real least. Become stay father late upon. Push police too cost. Compare rate suggest teach method enter. Keep identify commercial quality politics. Entire per night fight nor until both."
        },
        "harga_otr": 722095933
    },
    {
        "id": 393,
        "name": "YAMAHA ABC134",
        "image": [
            {
                "picture": "/home/ayuhana/django/asiafmobile/imagex/c3i.jpg"
            },
            {
                "picture": "/home/ayuhana/django/asiafmobile/imagex/c2_mobilbox.jpg"
            },
            {
                "picture": "/home/ayuhana/django/asiafmobile/imagex/c2i.jpg"
            }
        ],
        "category": {
            "id": 1,
            "rep_image": [
                {
                    "picture": "/home/ayuhana/django/asiafmobile/imagex/lamorgini.jpg"
                }
            ],
            "name": "Combine",
            "classification": 1
        },
        "brand": {
            "name": "FORD"
        },
        "specification": {
            "id": 393,
            "transmisi": {
                "name": "Manual"
            },
            "bahan_bakar": {
                "name": "Bensin"
            },
            "manufacturing_year": 2021,
            "kilometer": "292",
            "konsumsi_bbm": 113,
            "torsi": 25,
            "kapasitas_mesin": 993,
            "kapasitas_penumpang": 98,
            "dimensi": "5mx5m",
            "deskripsi": "Measure physical establish improve after important. Head near trade catch start. Really financial international probably share for. Wonder allow bag talk say break sometimes. Best join eight."
        },
        "harga_otr": 1821767526
    },
    {
        "id": 400,
        "name": "KIA ABC852",
        "image": [
            {
                "picture": "/home/ayuhana/django/asiafmobile/imagex/c2_mobilbox_freezer.jpg"
            },
            {
                "picture": "/home/ayuhana/django/asiafmobile/imagex/c1a.jpg"
            },
            {
                "picture": "/home/ayuhana/django/asiafmobile/imagex/c3bm.jpg"
            }
        ],
        "category": {
            "id": 1,
            "rep_image": [
                {
                    "picture": "/home/ayuhana/django/asiafmobile/imagex/lamorgini.jpg"
                }
            ],
            "name": "Combine",
            "classification": 1
        },
        "brand": {
            "name": "AUDI"
        },
        "specification": {
            "id": 400,
            "transmisi": {
                "name": "Automatic"
            },
            "bahan_bakar": {
                "name": "Avtur"
            },
            "manufacturing_year": 2015,
            "kilometer": "328",
            "konsumsi_bbm": 155,
            "torsi": 14,
            "kapasitas_mesin": 699,
            "kapasitas_penumpang": 99,
            "dimensi": "30mx20m",
            "deskripsi": "Pm evening meet common his. Significant star throughout laugh draw outside miss. Sort move president method analysis life. Save country always music mission dog."
        },
        "harga_otr": 928252182
    }
    ]
""";



var apiUrl = Uri.http('192.168.0.106:8080','/prod-by-spec/1');

//final String apiUrl ='http://192.168.0.106:8080/prod-by-spec/2';

final http.Response response = await http.get(apiUrl);

if (response.statusCode == 200)
{


List<dynamic> products = jsonDecode(response.body);



List<Product> product_list=[];



for (var product in products){
    List<Image> product_image_list =[];
    for (var image in product['image']){
      product_image_list.add(Image.fromMap(image));
    }
    print(product_image_list[0].url);

    //Convert Category picture
    List<Image> category_image_list=[];
    for (var image in product['category']['rep_image']){
      category_image_list.add(Image.fromMap(image));
    }    
    product_list.add(Product(
      product['id'],
      product['name'],
      product_image_list,
      Category(
        product['category']['id'],
        category_image_list,
        product['category']['name'],
        product['category']['classification']
        ),
      Brand.fromMap(product['brand']),
      Specification(
        product['specification']['id'],
        Transmisi.fromMap(product['specification']['transmisi']),
        BahanBakar.fromMap(product['specification']['bahan_bakar']),
        product['specification']['manufacturing_year'],
        product['specification']['kilometer'],
        product['specification']['konsumsi_bbm'],
        product['specification']['torsi'],
        product['specification']['kapasitas_mesin'],
        product['specification']['kapasitas_penumpang'],
        product['specification']['dimensi'],
        product['specification']['deskripsi']
        ),
      product['harga_otr']
    ));

  }

  for (var product in product_list){
      print(product.brand.name);
      for (var image in product.image){
        print(image.url);
      }
  }

}

}
