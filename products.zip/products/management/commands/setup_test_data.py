#setup_test_data.ppy

import random
from django.db import transaction
from django.core.management.base import BaseCommand

import time

from products.models import Product,ProductSpecification,Transmisi,BahanBakar,Picture,ProductCategory,ProductBrand
from products.factories import (
    ProductFactory,
    ProductSpecificationFactory
)

NUM_PRODUCTS = 100
NUM_SPECIFICATIONS = 100

transmisi_list = ['Automatic','Manual']
bahanbakar_list = ['Avtur','Solar','Bensin']
dimensi_list = ['30mx20m','10mx20m','5mx5m']

picture_list=  ["/images/lamorgini.jpg",
                "/images/agriculture.png",
                "/images/p_alphard.jpg",
                "/images/p_brv.png",
                "/images/p_crv.jpg",
                "/images/p_fortuner.jpg",
                "/images/p_innova.jpg",
                "/images/p_lamorgini.jpg",
                "/images/p_mobilio.jpg",
                "/images/c1a.jpg",
                "/images/c1b.jpg",
                "/images/c1c.jpg",
                "/images/c2bh.jpg",
                "/images/c2bi.jpg",
                "/images/c2bm.jpg",
                "/images/c2ch.jpg",
                "/images/c2ci.jpg",
                "/images/c2cm.jpg",
                "/images/c2di.jpg",
                "/images/c2h.jpg",
                "/images/c2i.jpg",
                "/images/c2m.jpg",
                "/images/c3bm.jpg",
                "/images/c3h.jpg",
                "/images/c3i.jpg",
                "/images/c3m.jpg",
                #Category Niaga 1
                "/images/c1_flatdeck.jpg",
                "/images/c1_mobilbox.jpg",
                "/images/c1_mobilbox_freezer.jpg",
                "/images/c1_pickup.jpg",
                #Category Niaga 2
                "/images/c2_dumptruck.jpg",
                "/images/c2_flatdeck.jpg",
                "/images/c2_microbus.jpg",
                "/images/c2_mobilbox.jpg",
                "/images/c2_mobilbox_freezer.jpg",
                "/images/c2_truck_mixer.jpg",
                "/images/c2_truck_tangki.jpg",
                "/images/c2_truck.png",
                #Category Niaga 3
                "/images/c3_crane.jpg",
                "/images/c3_headtractor.png",
                "/images/c3_wingbox.jpg",
                "/images/p_jeep.jpg",
                "/images/p_minibus.jpg",
                "/images/p_others.jpg",
                "/images/p_sedan.jpg"]



brand_list=["AUDI",
            "BENT",
            "BIMANTARA",
            "BMW",
            "CHEVROLET",
            "CHRYSLER",
            "DAEWOO",
            "DAIHATSU",
            "FORD",
            "Hitachi",
            "Caterpillar",
            "Komatsu",
            "China Textmat",
            "NEC",
            "HINO",
            "MITSUBISHI",
            "HONDA",
            "TOYOTA",
            "ISUZU",
            "KIA",
            "KAWASAKI",
            "MAZDA",
            "NISSAN",
            "SUZUKI",
            "YAMAHA"]

category_list =["Combine",
                "Tractor",
                "Sedan",
                "Jeep",
                "Minibus",
                "Other",
                "Pickup",
                "Box",
                "Box Freezer",
                "FlatDeck",
                "Other",
                "Truck",
                "Dump Truck",
                "Box",
                "Box Freezer",
                "Microbus",
                "Flat Deck",
                "Truck Tangki",
                "Truk Mixer",
                "Other",
                "Crane",
                "Wingbox",
                "Head Tractor"]

class Command(BaseCommand):
    help = "Generates test data"

    @transaction.atomic
    def handle(self,*args,**kwargs):
        self.stdout.write("Deleting old data")
        models = [Product,ProductSpecification]
        for m in models:
            m.objects.all().delete()

        self.stdout.write("Creating new data")
        random.seed(time.time())
        productspecifications = []
        for _ in range(NUM_PRODUCTS):
            productspecification= ProductSpecificationFactory(
                manufacturing_year= random.randrange(2015,2023), 
                transmisi = Transmisi.objects.get(name=random.choice(transmisi_list)),
                kilometer = str(random.randrange(100,1000)),
                bahan_bakar = BahanBakar.objects.get(name=random.choice(bahanbakar_list)),
                konsumsi_bbm = random.randrange(100,200),
                torsi = random.randrange(10,100),
                kapasitas_mesin = random.randrange(500,2000),
                kapasitas_penumpang = random.randrange(2,100),
                dimensi = random.choice(dimensi_list),
            )
            productspecifications.append(productspecification)

        products = []
        for spec in productspecifications:
            product= ProductFactory(
                name = random.choice(brand_list)+" "+random.choice(["XYZ","UIE","ABC"])+str(random.randrange(100,999)),
                #image = [Picture.objects.get(id=random.randrange(1,45)),Picture.objects.get(id=random.randrange(1,45)),Picture.objects.get(id=random.randrange(1,45))],
                category = ProductCategory.objects.filter(name=random.choice(category_list)).first(),
                #if category=""
                brand = ProductBrand.objects.filter(name=random.choice(brand_list)).first(),
                harga_otr = random.randrange(100_000_000,2_000_000_000),
                specification = spec,
            )
            img_id_list = [random.randrange(1,45),random.randrange(1,45),random.randrange(1,45)]
            img = Picture.objects.filter(id__in=img_id_list)
            product.image.set(img)
            products.append(product)        