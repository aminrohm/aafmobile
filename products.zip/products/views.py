from django.shortcuts import render
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status
from django.http import Http404
from .serials import ProductSerializer,ProductClassificationSerializer, ProductBrandSerializer, PictureSerializer, ProductCategorySerializer,ProductSpecificationSerializer,TransmisiSerializer,BahanBakarSerializer
from .models import Product,ProductClassification, ProductBrand, Picture, ProductCategory,ProductSpecification,Transmisi,BahanBakar
from rest_framework import serializers
# Create your views here.

    
#class SearchProduct(APIView):
#    def get(self,request):
#        product = Product.objects.filter(Q(brand__icontains=brand))


class GetProduct(APIView):
    def get(self,request,id=None):
        if id:
            product = Product.objects.get(id=id)
            print(product)
            serializer = ProductSerializer(product)
            print(serializer.data['image'])
            return Response(serializer.data, status=status.HTTP_200_OK)

        product = Product.objects.all()
        print(product)
        serializer = ProductSerializer(product,many=True)
        #print(serializer.data)
        return Response(serializer.data,status=status.HTTP_200_OK)
        #return Response({"product":product})

class GetProductSpecification(APIView):
    def get(self,request,id):
        product_specification = ProductSpecification.objects.get(product=Product.objects.get(id=id))
        serializer = ProductSpecificationSerializer()
        return Response(serializer.data,status=status.HTTP_200_OK)
    

class GetProductByClassification(APIView):
    def get(self,request,id):
        category = ProductCategory.objects.get(id=id)
        products = Product.objects.filter(category=category)
        serializer = ProductSerializer(products,many=True)
        return Response(serializer.data,status=status.HTTP_200_OK)





    
