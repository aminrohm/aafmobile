from django.db import models

# Create your models here.

class Picture(models.Model):
    picture =  models.ImageField(upload_to='images/')
    def __str__(self):
        return self.picture.url

class ProductClassification(models.Model):
    name = models.CharField(max_length=255)
    rep_image = models.ManyToManyField(Picture,blank=True,related_name="classification_picture_of")
    
    def __str__(self):
        return str(self.name)

class ProductCategory(models.Model):
    classification = models.ForeignKey(ProductClassification,on_delete=models.CASCADE)
    name = models.CharField(max_length=255)
    rep_image = models.ManyToManyField(Picture,blank=True,related_name="category_picture_of")

    def __str__(self):
        return str(self.name)
        
class ProductBrand(models.Model):
    name = models.CharField(max_length=255)

    def __str__(self):
        return str(self.name)
        
class Transmisi(models.Model):
    name = models.CharField(max_length=255)

    def __str__(self):
        return str(self.name)
        
class BahanBakar(models.Model):
    name = models.CharField(max_length=255)

    def __str__(self):
        return str(self.name)

class ProductSpecification(models.Model):
    manufacturing_year = models.IntegerField()
    transmisi = models.ForeignKey(Transmisi,on_delete=models.CASCADE)
    kilometer = models.CharField(max_length=100)
    bahan_bakar = models.ForeignKey(BahanBakar,on_delete=models.CASCADE)
    konsumsi_bbm = models.IntegerField()
    torsi = models.IntegerField()
    kapasitas_mesin = models.IntegerField()
    kapasitas_penumpang = models.IntegerField()
    dimensi = models.CharField(max_length=100)
    deskripsi = models.TextField()
    
    def __str__(self):
       return str(self.id)   



       
class Product(models.Model):
    name = models.CharField(max_length=255)
    image = models.ManyToManyField(Picture,blank=True,related_name="product_picture_of")
    category = models.ForeignKey(ProductCategory,related_name="has_category",on_delete=models.CASCADE)
    brand = models.ForeignKey(ProductBrand,related_name="has_brand",on_delete=models.CASCADE)
    harga_otr = models.BigIntegerField()
    specification = models.OneToOneField(ProductSpecification,on_delete=models.CASCADE,related_name="specification_of")
    
    def __str__(self):
        return str(self.name)
        
        
       