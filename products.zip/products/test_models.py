from django.test import TestCase

from model_mommy import mommy
from model_mommy.recipe import Recipe,foreign_key
import random
from django.db import transaction
from django.core.management.base import BaseCommand

from .models import ProductSpecification,Product


