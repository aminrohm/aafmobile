import factory
from factory.django import DjangoModelFactory

from .models import Product,ProductSpecification


class ProductSpecificationFactory(DjangoModelFactory):
    class Meta:
        model = ProductSpecification

    deskripsi = factory.Faker("paragraph",nb_sentences=5,variable_nb_sentences=True)


class ProductFactory(DjangoModelFactory):

    class Meta:
        model = Product
    
    specification = factory.SubFactory(ProductSpecificationFactory)



        