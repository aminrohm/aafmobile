import 'dart:convert';

import 'package:aafmobile/repositories/models/product.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:http/http.dart' as http;
import 'package:http/http.dart';
import 'package:aafmobile/repositories/models/informasi.dart';
import 'package:aafmobile/repositories/models/common.dart';

class AsiafMobileService {
  AsiafMobileService({
    http.Client? httpClient,
    //this.baseUrl = 'http://192.168.50.38:8011',
    this.baseUrl = 'http://192.168.0.106:8080'
  }) : _httpClient = httpClient ?? http.Client();

  final String baseUrl;
  final Client _httpClient;

  Uri getUrl({
    required String url,
  }) {
    return Uri.parse('$baseUrl/$url');
  }

  Future<List<Informasi>> getAllInformasi() async {
    //final Response response = await get(getUrl(url:'info'));
    final Response response = await get(Uri.parse('$baseUrl/info'));
    if (response.statusCode == 200) {
      if (response.body.isNotEmpty) {
        List<dynamic> infos = jsonDecode(response.body);
        List<Informasi> info_list=[];

        for (var info in infos){
          List<Image> info_image_list =[];
          for (var image in info['images']){
            image['picture']= this.baseUrl+image['picture'];
            info_image_list.add(Image.fromMap(image));
          }
          info_list.add(Informasi(
              info['id'],
              info['title'],
              info_image_list,
              info['contents']
          ));

        }
        return info_list;
      } else {
        //throw ErrorEmptyResponse();
        throw Exception(response.reasonPhrase);
      }
    } else {
      throw Exception(response.reasonPhrase);
    }
  }

  Future<Informasi> getInformasiDetail(int id) async{
    final Response response = await get(Uri.parse('$baseUrl/info/'+id.toString()));
    print("response");
    print(response.statusCode);
    print(id.toString());
    if (response.statusCode == 200) {
      print(response.body);
      if (response.body.isNotEmpty) {
        final result = jsonDecode(response.body);
        print("result");
        print(result);

        List<Image> info_image_list =[];
        for (var image in result['images']){
          //String slash="\";
          print('before');
          print(this.baseUrl);
          print(image['picture']);
          image['picture']= this.baseUrl+image['picture'];
          print("after");
          print(image['picture']);
          info_image_list.add(Image.fromMap(image));
        }
        return Informasi(
            result['id'],
            result['title'],
            info_image_list,
            result['contents']
        );
        //return result.map((e) => Informasi.fromJson(e)).toList();
        //return info;

      } else {
        //throw ErrorEmptyResponse();
        throw Exception(response.reasonPhrase);
      }
    } else {
      throw Exception(response.reasonPhrase);
    }
  }

  Future<List<Classification>> getProductClassification() async{
    final Response response = await get(Uri.parse('$baseUrl/class/'));
    //final Response response = await get(getUrl(url:'class'));
    if (response.statusCode == 200) {
      if (response.body.isNotEmpty) {
        List<dynamic> classification = jsonDecode(response.body);
        List<Classification> classification_list=[];
        print("GET PRODUCT CLASSIFICATON");
        print(response.body.toString());

        for (var classy in classification){
          List<Image> classy_image_list =[];
          for (var image in classy['rep_image']){
            image['picture']= this.baseUrl+image['picture'];
            classy_image_list.add(Image.fromMap(image));
          }
          classification_list.add(Classification(
              classy['id'],
              classy['name'],
              classy_image_list
          ));
        }
        return classification_list;
      } else {
        //throw ErrorEmptyResponse();
        throw Exception(response.reasonPhrase);
      }
    } else {
      throw Exception(response.reasonPhrase);
    }
  }

  Future<List<Product>> getProductByClassification(int class_id,int page) async{
    //final Response response = await get(getUrl(url:'prod-by-class'));
    final Response response = await get(Uri.parse('$baseUrl/prod-by-class/'+class_id.toString()+'/'+page.toString()));
    if (response.statusCode == 200) {
      if (response.body.isNotEmpty) {
        List<dynamic> products = jsonDecode(response.body);
        List<Product> product_list=[];

        for (var product in products){
          List<Image> product_image_list =[];
          for (var image in product['image']){
            image['picture']= this.baseUrl+image['picture'];
            product_image_list.add(Image.fromMap(image));
          }
          List<Image> category_image_list=[];
          for (var image in product['category']['rep_image']){
            category_image_list.add(Image.fromMap(image));
          }

          product_list.add(Product(
              product['id'],
              product['name'],
              product_image_list,
              Category(
                  product['category']['id'],
                  category_image_list,
                  product['category']['name'],
                  product['category']['classification']
              ),
              Brand.fromMap(product['brand']),
              Specification(
                  product['specification']['id'],
                  Transmisi.fromMap(product['specification']['transmisi']),
                  BahanBakar.fromMap(product['specification']['bahan_bakar']),
                  product['specification']['manufacturing_year'],
                  product['specification']['kilometer'],
                  product['specification']['konsumsi_bbm'],
                  product['specification']['torsi'],
                  product['specification']['kapasitas_mesin'],
                  product['specification']['kapasitas_penumpang'],
                  product['specification']['dimensi'],
                  product['specification']['deskripsi']
              ),
              product['harga_otr']
          ));

        }
        return product_list;
      } else {
        //throw ErrorEmptyResponse();
        throw Exception(response.reasonPhrase);
      }
    } else {
      throw Exception(response.reasonPhrase);
    }
  }

  Future<int?> getProductByClassificationCount(int class_id) async {
    final Response response = await get(Uri.parse('$baseUrl/prod-by-class-count/'+class_id.toString()));
    if (response.statusCode==200){
      if (response.body.isNotEmpty){
        print("response body");
        print(response.body);
        dynamic encode_result = jsonDecode(response.body);
        print("encode result");
        print(encode_result);
        //ret_value = int.parse(encode_result['count'])?? 999;
        print("encode_result['count']");
        print(encode_result['count']);
        return encode_result['count'];
      }
      else{
        throw Exception(response.reasonPhrase);
      }
    }
  }


  Future<List<Product>> searchProductByBrandAndPrice(int brand_id,int price) async{
    //final Response response = await get(getUrl(url:'prod-by-class'));
    final Response response = await get(Uri.parse('$baseUrl/search/'+brand_id.toString()+'/'+price.toString()));
    if (response.statusCode == 200) {
      if (response.body.isNotEmpty) {
        List<dynamic> products = jsonDecode(response.body);
        List<Product> product_list=[];

        for (var product in products){
          List<Image> product_image_list =[];
          for (var image in product['image']){
            image['picture']= this.baseUrl+image['picture'];
            product_image_list.add(Image.fromMap(image));
          }
          List<Image> category_image_list=[];
          for (var image in product['category']['rep_image']){
            category_image_list.add(Image.fromMap(image));
          }

          product_list.add(Product(
              product['id'],
              product['name'],
              product_image_list,
              Category(
                  product['category']['id'],
                  category_image_list,
                  product['category']['name'],
                  product['category']['classification']
              ),
              Brand.fromMap(product['brand']),
              Specification(
                  product['specification']['id'],
                  Transmisi.fromMap(product['specification']['transmisi']),
                  BahanBakar.fromMap(product['specification']['bahan_bakar']),
                  product['specification']['manufacturing_year'],
                  product['specification']['kilometer'],
                  product['specification']['konsumsi_bbm'],
                  product['specification']['torsi'],
                  product['specification']['kapasitas_mesin'],
                  product['specification']['kapasitas_penumpang'],
                  product['specification']['dimensi'],
                  product['specification']['deskripsi']
              ),
              product['harga_otr']
          ));

        }
        return product_list;
      } else {
        //throw ErrorEmptyResponse();
        throw Exception(response.reasonPhrase);
      }
    } else {
      throw Exception(response.reasonPhrase);
    }
  }

  Future<List<String>> getBrandInClassification(int class_id) async{
    final Response response = await get(Uri.parse('$baseUrl/search/'+class_id.toString()));
    //final Response response = await get(getUrl(url:'class'));
    if (response.statusCode == 200) {
      if (response.body.isNotEmpty) {
        List<dynamic> brands = jsonDecode(response.body);
        List<String> brand_list=[];
        print("GET BRAND LIST");
        print(response.body.toString());

        for (var brand in brands){
          brand_list.add(brand['name']);
        }
        return brand_list;
      } else {
        //throw ErrorEmptyResponse();
        throw Exception(response.reasonPhrase);
      }
    } else {
      throw Exception(response.reasonPhrase);
    }
  }














/*
  Future<Game> getGames() async {
    final response = await _httpClient.get(
      getUrl(url: 'games'),
    );
    if (response.statusCode == 200) {
      if (response.body.isNotEmpty) {
        return Game.fromJson(
          json.decode(response.body),
        );
      } else {
        throw ErrorEmptyResponse();
      }
    } else {
      throw ErrorGettingGames('Error getting games');
    }
  }

  Future<List<Genre>> getGenres() async {
    final response = await _httpClient.get(
      getUrl(url: 'genres'),
    );
    if (response.statusCode == 200) {
      if (response.body.isNotEmpty) {
        return List<Genre>.from(
          json.decode(response.body)['results'].map(
                (data) => Genre.fromJson(data),
              ),
        );
      } else {
        throw ErrorEmptyResponse();
      }
    } else {
      throw ErrorGettingGames('Error getting genres');
    }
  }

  Future<List<Result>> getGamesByCategory(int genreId) async {
    final response = await _httpClient.get(
      getUrl(
        url: 'games',
        extraParameters: {
          'genres': genreId.toString(),
        },
      ),
    );
    if (response.statusCode == 200) {
      if (response.body.isNotEmpty) {
        return List<Result>.from(
          json.decode(response.body)['results'].map(
                (data) => Result.fromJson(data),
              ),
        );
      } else {
        throw ErrorEmptyResponse();
      }
    } else {
      throw ErrorGettingGames('Error getting games');
    }
  }
*/
}



