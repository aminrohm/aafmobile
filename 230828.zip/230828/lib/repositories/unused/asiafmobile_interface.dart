import 'package:aafmobile/models/informasi.dart';
import 'package:aafmobile/models/category.dart';
import 'package:aafmobile/models/produk_item.dart';

abstract class AsiafMobileRepository {
  Future<List<Informasi>> getAll_informasi();
  Future<Informasi?> getOne_informasi(int id);
  Future<void> insert_informasi(Informasi informasi);
  Future<void> update_informasi(Informasi informasi);
  Future<void> delete_informasi(int id);

  //Future<List<Category>> getAll_category();
  //Future<Category?> getOne_category(int id);
  //Future<void> insert_category(Category category);
  //Future<void> update_category(Category category);
  //Future<void> delete_category(int id);

  //Future<List<ProdukItem>> getAll_produkitem();
  //Future<ProdukItem?> getOne_produkitem(int id);
  //Future<void> insert_produkitem(ProdukItem produkItem);
  //Future<void> update_produkitem(ProdukItem produkItem);
  //Future<void> delete_produkitem(int id);

}