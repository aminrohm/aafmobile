import './common.dart';



class Informasi{
    final int id;
    final String title;
    final List<Image> images;
    final String contents;


    //List<String> image_urls=[];

    Informasi(this.id,
           this.title,
           this.images,
           this.contents);


    List<Image> get_images(List<Map<String,dynamic>> data){
        List<Image> img=[];
        for (var i in data){
          img.add(Image.fromMap(i));
        }
        return img;
    }



    Informasi.fromMap(Map<String,dynamic> data):
            id = data['id'],
            title = data['title'],
            images = data['images'],
            contents = data['contents'];




    Map<String,dynamic> toMap(){
        return {
          'id': id,
          'title' : title,
          'images' : images,
          'contents' : contents
        };
      } 

    Informasi.fromJson(Map<String,dynamic> data):
            id = data['id'],
            title = data['title'],
            images = data['images'],
            contents = data['contents'];

    Map<String,dynamic> toJson(){
        return {
          'id': id,
          'title' : title,
          'images' : images,
          'contents' : contents
        };
      } 




}