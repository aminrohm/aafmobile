
class Image {
    final String url;

    Image(this.url);

    Image.fromMap(Map<String,dynamic> data):
        url = data['picture'];

    Map<String,dynamic> toMap(){
        return {
            'picture': url
        };
    }

    Image.fromJson(Map<String,dynamic> data):
        url = data['picture'];

    Map<String,dynamic> toJson(){
        return {
            'picture': url
        };
    }

}

