class Category{
  final int id;
  final String title;
  final String image_url;
  final String description;


  Category(this.id,this.title,this.image_url,this.description);

  Category.fromMap(Map<String,dynamic> data):
      id = data['id'],
      title = data['title'],
      image_url = data['image_url'],
      description = data['description'];

  Map<String,dynamic> toMap(){
        return {
          'id': id,
          'title' : title,
          'image_url' : image_url,
          'description' : description
        };
      }


}