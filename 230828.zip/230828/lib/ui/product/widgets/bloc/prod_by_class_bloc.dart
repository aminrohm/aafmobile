import 'dart:async';

//import 'package:brewtiful/remote/beer_summary.dart';
//import 'package:brewtiful/remote/remote_api.dart';
import 'package:aafmobile/repositories/models/product.dart';
import 'package:aafmobile/repositories/asiafmobile.dart';
import 'package:rxdart/rxdart.dart';

class ProductListingState {
  ProductListingState({
    this.itemList,
    this.error,
    this.nextPageKey = 1,
  });

  //final List<Product>? itemList;
  final List<Product>? itemList;
  final dynamic error;
  final int? nextPageKey;
}



class ProductListingBloc {
  final AsiafMobileRepository asiafmobileRepository;
  int class_id=0;
  List<String> brands=[];
  int price=
  ProductListingBloc({
    required this.asiafmobileRepository,}) {
    _onPageRequest.stream
        .flatMap(_fetchProductList)
        .listen(_onNewListingStateController.add)
        .addTo(_subscriptions);

    //PRICE
    _onSearchPriceChangedSubject.stream
        .flatMap(_filterProductByBrandAndPrice)
        .listen(_onNewListingStateController.add)
        .addTo(_subscriptions);

    //BRAND
    _onSearchBrandChangedSubject.stream
        .flatMap(_filterProductByBrandAndPrice)
        .listen(_onNewListingStateController.add)
        .addTo(_subscriptions);

  }

  static const _pageSize = 4; // original is 10

  final _subscriptions = CompositeSubscription();

  set set_class_id(int class_id){
    this.class_id = class_id;
  }

set set_brands(int class_id) async* {
  try{
    final newItems = await asiafmobileRepository.getBrandInClassification(
      this.class_id,
    );
    brands= newItems;
  }
  catch(e){
   print(e);
  }
}


  final _onNewListingStateController = BehaviorSubject<ProductListingState>.seeded(
    ProductListingState(),
  );

  Stream<ProductListingState> get onNewListingState =>
      _onNewListingStateController.stream;

  final _onPageRequest = StreamController<int>();

  Sink<int> get onPageRequestSink => _onPageRequest.sink;

  // Brand
  final _onSearchBrandChangedSubject = BehaviorSubject<String?>.seeded(null);
  Sink<String?> get onSearchBrandChangedSink =>_onSearchBrandChangedSubject.sink;
  String? get _searchBrandValue => _onSearchBrandChangedSubject.value;

  //Price
  final _onSearchPriceChangedSubject = BehaviorSubject<String?>.seeded(null);
  Sink<String?> get onSearchPriceChangedSink =>_onSearchPriceChangedSubject.sink;
  String? get _searchPriceValue => _onSearchPriceChangedSubject.value;


  Stream<ProductListingState> _resetSearch() async* {
    yield ProductListingState();
    yield* _fetchProductList(1);
  }



  //Filter product by brand and price
  Stream<ProductListingState> _filterProductByBrandAndPrice(int pageKey) async* {
    try{
      final newItems = await asiafmobileRepository.filterProductByBrandAndPrice(
        this.class_id,
//        pageKey,
        brand : _searchBrandValue,
        price : _searchPriceValue,
      );
      final isLastPage = newItems.length < _pageSize;
      final nextPageKey = isLastPage ? null : pageKey + 1;
      yield ProductListingState(
        error: null,
        nextPageKey: nextPageKey,
        itemList: [
          ...lastListingState.itemList ?? [],
          ...newItems,
        ],
      );
    }
    catch(e){
      yield ProductListingState(
      error: e,
      nextPageKey: lastListingState.nextPageKey,
      itemList: lastListingState.itemList,
      );
    }
  }

  Stream<ProductListingState> _fetchProductList(int pageKey) async* {
    final lastListingState = _onNewListingStateController.value;
    try {
      //final newItems = await RemoteApi.getBeerList(
      //  pageKey,
      //  _pageSize,
      //  searchTerm: _searchInputValue,
      //);
      print("class_id");
      print(this.class_id);
      final newItems = await asiafmobileRepository.getProductByClassification(
        this.class_id,
        pageKey,
      );
      final isLastPage = newItems.length < _pageSize;
      final nextPageKey = isLastPage ? null : pageKey + 1;
      yield ProductListingState(
        error: null,
        nextPageKey: nextPageKey,
        itemList: [
          ...lastListingState.itemList ?? [],
          ...newItems,
        ],
      );
    } catch (e) {
      yield ProductListingState(
        error: e,
        nextPageKey: lastListingState.nextPageKey,
        itemList: lastListingState.itemList,
      );
    }
  }

  void dispose() {
    _onSearchPriceChangedSubject.close();
    _onSearchBrandChangedSubject.close();
    _onNewListingStateController.close();
    _subscriptions.dispose();
    _onPageRequest.close();
  }


}