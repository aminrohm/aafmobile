import 'dart:async';

import 'package:flutter/material.dart';
import 'package:rxdart/rxdart.dart';

class SearchBrandSliver extends StatefulWidget {
  const SearchBrandSliver({
    Key? key,
    this.onChanged,
    this.debounceTime,
    this.dropdownValue,
  }) : super(key: key);
  final ValueChanged<String>? onChanged;
  final Duration? debounceTime;
  final List<String? dropdownValue;

  @override
  _SearchBrandSliverState createState() => _SearchBrandSliverState();
}

class _SearchBrandSliverState extends State<SearchBrandSliver> {
  final StreamController<String> _brandChangeStreamController =
  StreamController();
  late StreamSubscription _brandChangesSubscription;

  @override
  void initState() {
    _brandChangesSubscription = _brandChangeStreamController.stream
        .debounceTime(
      widget.debounceTime ??
          const Duration(seconds: 1,),
    )
        .distinct()
        .listen((text) {
      final onChanged = widget.onChanged;
      if (onChanged != null) {
        onChanged(text);
      }
    });
    //get dropdownvalue

    super.initState();
  }

  @override
  Widget build(BuildContext context) => SliverToBoxAdapter(
    child: Padding(
      padding: const EdgeInsets.all(16,),
      child: DropdownButton<String>(
        value: widget.dropdownValue,
        icon: const Icon(Icons.arrow_downward),
        elevation: 16,
        style: const TextStyle(color: Colors.deepPurple),
        underline: Container(
          height: 2,
          color: Colors.deepOrange,
        ),
        onChanged: (String? value){
        },
      ),
      ),
  );

  @override
  void dispose() {
    _brandChangeStreamController.close();
    _brandChangesSubscription.cancel();
    super.dispose();
  }
}