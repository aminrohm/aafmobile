import 'package:flutter/material.dart';
import 'package:aafmobile/repositories/service/asiafmobile.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:aafmobile/repositories/asiafmobile.dart';
import 'package:aafmobile/ui/product/widgets/bloc/prod_by_class_bloc.dart';
import 'package:aafmobile/ui/product/pages/product_by_class_layout.dart';

class ProductByClassPage extends StatelessWidget {
  final int class_id;
  final String class_name;
  const ProductByClassPage({Key? key,required this.class_id,required this.class_name}):super(key:key);

  @override
  Widget build(BuildContext context){
    return Scaffold(
      body:RepositoryProvider(
        create: (context)=> AsiafMobileRepository(service: AsiafMobileService()),
        child: ProductByClassLayout(class_id:class_id,class_name:class_name),

        /*
        child: MultiBlocProvider(
          providers: [
            BlocProvider<ProductByClassBloc>(
              create: (context) => ProductByClassBloc(
              asiafmobileRepository: context.read<AsiafMobileRepository>(),
            )..add(GetProductByClassEvent(product_list:const [],class_id: class_id,page:1)),
            ),
          ],
          child: ProductByClassLayout(class_id: class_id),
          */

        ),
      );

  }


  }

