//import 'dart:js_interop';

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:aafmobile/repositories/service/asiafmobile.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:aafmobile/repositories/models/informasi.dart';
import 'package:aafmobile/repositories/asiafmobile.dart';
import 'package:equatable/equatable.dart';
import 'package:aafmobile/ui/product/widgets/bloc/prod_by_class_bloc.dart';
import 'package:infinite_widgets/infinite_widgets.dart';
//import 'package:aafmobile/ui/product/widgets/bloc/product_page_cubit.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:intl/intl.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:rxdart/rxdart.dart';
import 'package:aafmobile/repositories/models/product.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:aafmobile/ui/product/widgets/bloc/search_price_sliver.dart';
import 'package:aafmobile/ui/product/widgets/bloc/search_brand_sliver.dart';

const List<String> list = <String>['One', 'Two', 'Three', 'Four'];

class ProductByClassLayout extends StatefulWidget{
  final int class_id;
  final String class_name;

  ProductByClassLayout({Key? key,required this.class_id,required this.class_name}):super(key:key);

  @override
  _ProductByClassLayout createState() => _ProductByClassLayout();
}


class _ProductByClassLayout extends State<ProductByClassLayout> {

  final ProductListingBloc _bloc=ProductListingBloc(asiafmobileRepository: AsiafMobileRepository(
      service: AsiafMobileService()));
  final PagingController<int,Product> _pagingController = PagingController(firstPageKey:1);
  late StreamSubscription _blocListingStateSubscription;

  void initState() {
    _pagingController.addPageRequestListener((pageKey) {
      _bloc.set_class_id = widget.class_id;
      _bloc.onPageRequestSink.add(pageKey);
    });
    _blocListingStateSubscription =
        _bloc.onNewListingState.listen((listingState) {
          _pagingController.value = PagingState(
            nextPageKey: listingState.nextPageKey,
            error: listingState.error,
            itemList: listingState.itemList,
          );
        });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Category: "+widget.class_name),),
      body:CustomScrollView(
    slivers: <Widget>[
    //Text("AAA"),
    SearchBrandSliver(
      dropdownValue: [],
      onChanged: (searchTerm) => _bloc.onSearchBrandChangedSink.add(searchTerm,),
    ),
      SearchPriceSliver(
        onChanged: (searchTerm) => _bloc.onSearchPriceChangedSink.add(searchTerm,),
      ),
    PagedSliverGrid<int, Product>(
        pagingController: _pagingController,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        childAspectRatio: 100 / 100,
        crossAxisSpacing: 10,
        mainAxisSpacing: 1,
        crossAxisCount: 2,
    ),
      builderDelegate: PagedChildBuilderDelegate<Product>(
        //itemBuilder: (context, item, index) => CachedNetworkImage(
        //  imageUrl: item.image[0].url,
        itemBuilder: (context, item, index) =>
            Card(
              child: Column(
                children: <Widget>[
                  CachedNetworkImage(imageUrl: item.image[0].url,),
                  Center(child: Text(item.name, style: TextStyle(
                      color: Colors.black, fontWeight: FontWeight.bold),),),
                  Text("OTR mulai dari",
                      style: TextStyle(color: Colors.black26,)),
                  Center(child: Text(
                    NumberFormat("'Rp' #,###,000").format(item.harga_otr),
                    style: TextStyle(color: Colors.blueAccent,
                        fontWeight: FontWeight.bold),),),

                ],
              ),
            ),
      ),
    ),
    ],
    ) ,
    );

  }
    @override
    void dispose() {
      _pagingController.dispose();
      _blocListingStateSubscription.cancel();
      _bloc.dispose();
      super.dispose();
    }

}



