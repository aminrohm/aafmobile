import 'package:flutter/material.dart';
import 'package:aafmobile/repositories/service/asiafmobile.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:aafmobile/repositories/models/informasi.dart';
import 'package:aafmobile/repositories/asiafmobile.dart';
import 'package:equatable/equatable.dart';
import 'package:aafmobile/ui/beranda/widgets/informasi_widget/bloc/informasi_bloc.dart';
import 'package:aafmobile/ui/informasi/widgets/bloc/informasi_detail_bloc.dart';
import 'package:carousel_slider/carousel_slider.dart';




class InformasiDetailLayout extends StatelessWidget {
  const InformasiDetailLayout ({Key? key}):super(key:key);

  @override
  Widget build(BuildContext context){
  return BlocConsumer<InformasiDetailBloc,InformasiDetailState>(
    listener: (context,state){

    },
    builder: (context,state){
      if (state is InformasiDetailErrorState){
        return Text("Error");
      }
      if (state is InformasiDetailLoadingState){
        return CircularProgressIndicator();
      }
      if (state is InformasiDetailLoadedState){
        return Column(
          children: [
            Center(
              child: Text(state.informasi!.title),
            ),
            //InkWell(
           //   splashColor: Colors.greenAccent,
           //   child: Image.network(
           //     state.informasi!.images[0].url,
           //     fit: BoxFit.cover,
           //   ),
           // ),
            CarouselSlider(
              options: CarouselOptions(
                disableCenter: true,
                onPageChanged: (index,reason){
                  //BlocProvider.of<InformasiBloc>(context).add(
                  //  InformasiPageChangeEvent(list_informasi:state.list_informasi,index:index)
                  //);
                  //current_pos = index;
                },
              ),
              //items: list_image.map((imageUrl) {
              items: state.informasi!.images.map((image){
                return Ink(
                  width: double.infinity,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(30),
                    image: DecorationImage(
                      image: NetworkImage(
                          image.url
                        //fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  child:InkWell(
                    splashColor: Colors.deepOrangeAccent,
                  ),
                );
              }).toList(),
              //autoplay: true,
              //interval: Duration(seconds: 3),
            ),
            Spacer(),
            Text(state.informasi!.contents),
          ],
        );
      }
      return Container();
    },
  );
  }


  }

