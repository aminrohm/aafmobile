import 'dart:io';

import 'package:flutter/material.dart';
import 'package:aafmobile/repositories/service/asiafmobile.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:aafmobile/repositories/models/informasi.dart';
import 'package:aafmobile/repositories/asiafmobile.dart';
import 'package:equatable/equatable.dart';

part 'informasi_detail_event.dart';
part 'informasi_detail_state.dart';




class InformasiDetailBloc extends Bloc<InformasiDetailEvent,InformasiDetailState>{
  final AsiafMobileRepository asiafmobileRepository;
  //int activePage=1;

  InformasiDetailBloc({
//    required activePage,
    required this.asiafmobileRepository,
}): super(InformasiDetailLoadingState()){
    on<GetInformasiDetailEvent>(_mapGetInformasiDetailEventToState);
  }



  void _mapGetInformasiDetailEventToState(
      GetInformasiDetailEvent Event,Emitter<InformasiDetailState> emit) async {
    emit(InformasiDetailLoadingState());
    try{
      final informasi_item = await asiafmobileRepository.getInformasiDetail(Event.data);
      emit(InformasiDetailLoadedState(informasi: informasi_item));
    }catch(error,stacktrace){
      debugPrint(stacktrace.toString());
      emit(InformasiDetailErrorState(error.toString()));
    }
  }



}

