import 'dart:io';

import 'package:flutter/material.dart';
import 'package:aafmobile/repositories/service/asiafmobile.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:aafmobile/repositories/models/product.dart';
import 'package:aafmobile/repositories/asiafmobile.dart';
import 'package:equatable/equatable.dart';

part 'productclassification_event.dart';
part 'productclassification_state.dart';




class ProductClassificationBloc extends Bloc<ProductClassificationEvent,ProductClassificationState>{
  final AsiafMobileRepository asiafmobileRepository;
  //int activePage=1;

  ProductClassificationBloc({
//    required activePage,
    required this.asiafmobileRepository,
}): super(ProductClassificationLoadingState()){
    on<GetProductClassificationEvent>(_mapGetProductClassificationEventToState);
  }


  void _mapGetProductClassificationEventToState(
      GetProductClassificationEvent event,Emitter<ProductClassificationState> emit) async {
    emit(ProductClassificationLoadingState());
    try{
      final list_productclassification = await asiafmobileRepository.getProductClassification();
      emit(ProductClassificationLoadedState(list_productclassification:list_productclassification));
      //yield AllProductClassificationLoadedState(list_ProductClassification: list_ProductClassification, activePage: 0);
    }catch(error,stacktrace){
      debugPrint(stacktrace.toString());
      emit(ProductClassificationErrorState(error.toString()));
      //yield ProductClassificationErrorState(error.toString());
    }
  }







}

