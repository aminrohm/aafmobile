part of 'productclassification_bloc.dart';


@immutable
abstract class InformasiStateX extends Equatable {}


class ProductClassificationState extends Equatable {
  ProductClassificationState();

  @override
  List<Object?> get props => [];

}

class ProductClassificationLoadingState extends ProductClassificationState {

  ProductClassificationLoadingState();
  @override
  List<Object?> get props => [];
}

class ProductClassificationLoadedState extends ProductClassificationState {
  final List<Classification> list_productclassification;

  //ProductClassificationLoadedState({
  //  required List<Classification> list_productclassification,
  //});
  ProductClassificationLoadedState({required this.list_productclassification});

  ProductClassificationLoadedState copyWith({
    List<Classification>? list_productclassification,
  }) {
    return ProductClassificationLoadedState(
      list_productclassification : list_productclassification ?? this.list_productclassification,
    );
  }

  @override
  String toString() {
    return 'ProductClassificationLoaded(list_productclassification: $list_productclassification)';
  }

  //@override
  //List<Object?> get props => [list_informasi]; // decides which objects we should consider for object coprison.
}


class ProductClassificationErrorState extends ProductClassificationState {
  final String error;
  ProductClassificationErrorState(this.error);
  @override
  List<Object?> get props => [error];
}


  //@override
  //String toString(){
  //  return InformasiPageChangeState(index: $this.index);
  //}

  //@override
  //List<Object?> get props => [activePage];


