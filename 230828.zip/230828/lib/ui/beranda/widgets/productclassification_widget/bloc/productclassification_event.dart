part of 'productclassification_bloc.dart';

class ProductClassificationEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class GetProductClassificationEvent extends ProductClassificationEvent {

  @override
  List<Object?> get props => [];
}





