import 'package:aafmobile/repositories/asiafmobile.dart';
import 'package:aafmobile/repositories/models/product.dart';
import 'package:aafmobile/repositories/service/asiafmobile.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:aafmobile/ui/beranda/widgets/productclassification_widget/bloc/productclassification_bloc.dart';
import 'package:aafmobile/ui/routers/router.dart';


TValue? case2<TOptionType, TValue>(
    TOptionType selectedOption,
    Map<TOptionType, TValue> branches, [
      TValue? defaultValue = null,
    ]) {
  if (!branches.containsKey(selectedOption)) {
    return defaultValue;
  }

  return branches[selectedOption];
}


class ProductClassificationWidget extends StatelessWidget {
  const ProductClassificationWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context){
    return BlocConsumer<ProductClassificationBloc,ProductClassificationState>(
      listener: (context,state){

      },
      builder: (context,state) {
        //return Container(
        if (state is ProductClassificationErrorState) {
          return Text("Error");
        }
        if (state is ProductClassificationLoadingState) {
          return CircularProgressIndicator();
        }
        if (state is ProductClassificationLoadedState) {
          //List<Informasi> list_informasi = state.list_informasi;
          //List<String> list_image = [];
          //for (var i = 0; i < list_informasi.length; i++) {
          //  list_image.add(list_informasi[i].images[0].url);
          //}
          //return _buildImageCarouselWithIndicator(list_image, context);
          return Container(

            child:GridView(
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
              crossAxisSpacing: 16),
              children: state.list_productclassification.map((classification){
                return Ink(
                  width: double.infinity,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(30),
                    image: DecorationImage(
                    image: NetworkImage(
                        classification.image[0].url
                      //fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  child:InkWell(
                  splashColor: Colors.deepOrangeAccent,
                  onTap:() {
                    router.go('/prod-by-class/'+classification.id.toString()+'/'+classification.name);
                  },
                  child: Align(
                    child: Padding(
                      padding: EdgeInsets.all(10.0),
                      child: Text(
                        classification.name,
                        style: TextStyle(
                          fontWeight: FontWeight.w900,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ),
              );
              /*
                  return Column(
                    children:[
                      Text(classification.name),
                      Ink(
                        width: double.infinity,
                        decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(30),
                        image: DecorationImage(
                        image: NetworkImage(
                        classification.image[0].url
                        //fit: BoxFit.cover,
                        ),
                        ),
                        ),
                        child:InkWell(
                        splashColor: Colors.deepOrangeAccent,
                        onTap:() {
                        router.go('/beranda/informasi-details/'+classification.id.toString());
                        },
                        ),
                        ),
                    ]
                  );

               */

            }).toList(),
          ),
          );
        }
        return Container();
      }
      );
      }
    //);

    /*
    return BlocProvider(
      //buildWhen: (previous,current) => current.status.isSuccess,
      create: (context) => InformasiBloc(asiafmobileRepository: AsiafMobileRepository(service: AsiafMobileService())),
      child: BlocConsumer<InformasiBloc,InformasiState>(
        listener: (context,state){
          //
        },
        //child: BlocBuilder<InformasiBloc,InformasiState>(
          builder: (context,state) {
            if(state is InformasiErrorState)
              {
                return Text("Error");
              }
            if(state is InformasiLoadingState)
            {
              return CircularProgressIndicator();
            }
            if(state is AllInformasiLoadedState)
              {
                List<Informasi> list_informasi = state.list_informasi;
                List<String> list_image = [];
                for(var i=0;i<list_informasi.length;i++) {
                  list_image.add(list_informasi[i].image_url);
                }
                /*
                return Column(
                  children: [
                    Container(
                      height:300,
                      child:PageView.builder(
                            itemCount: list_informasi.length,
                            pageSnapping: true,
                    //onPageChanged: (page) => context.read<InformasiBloc>().add(InformasiPageChange(data:page)),
                            //onPageChanged: (page) => context.read<InformasiBloc>().add(InformasiPageChange(data:page)),
                              itemBuilder: (context, pagePosition) {
                                  List<String> list_image = [];
                                  for(var i=0;i<list_informasi.length;i++) {
                                      list_image.add(list_informasi[i].image_url);
                                   }
                                  return Container(
                                      margin: EdgeInsets.all(10),
                                      child: InkWell(
                                          splashColor: Colors.greenAccent,
                                          onTap: () {},
                                          child: Image.network(list_image[pagePosition], fit: BoxFit.cover,),
                                    ),
                              );
                              },
                    )),
                //CarouselIndicator(
                //  count: list_informasi.length,
                //  index: state.activePage,
                //),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children:indicators(list_informasi.length,_activePage),
                    ),
                //);
                  ],
                );
                
                 */
                return _buildImageCarouselWithIndicator(list_image,context);
              }

            return Container();
        }
        //),
      ),
    );

     */

     
  }


//}


/*
List<Widget> indicators(imagesLength,currentIndex) {
  return List<Widget>.generate(imagesLength, (index) {
    return Container(
      margin: EdgeInsets.all(3),
      width: 10,
      height: 10,
      decoration: BoxDecoration(
          color: currentIndex == index ? Colors.black : Colors.black26,
          shape: BoxShape.circle),
    );
  });
}
*/

