import 'package:aafmobile/repositories/asiafmobile.dart';
import 'package:aafmobile/repositories/service/asiafmobile.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:aafmobile/ui/beranda/widgets/informasi_widget/bloc/informasi_bloc.dart';
import 'package:aafmobile/repositories/models/informasi.dart';
import 'package:carousel_indicator/carousel_indicator.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:dots_indicator/dots_indicator.dart';
import 'package:aafmobile/ui/informasi/pages/informasi_detail_page.dart';
import 'package:aafmobile/ui/routers/router.dart';


TValue? case2<TOptionType, TValue>(
    TOptionType selectedOption,
    Map<TOptionType, TValue> branches, [
      TValue? defaultValue = null,
    ]) {
  if (!branches.containsKey(selectedOption)) {
    return defaultValue;
  }

  return branches[selectedOption];
}


class InformasiWidget extends StatelessWidget {
  const InformasiWidget({Key? key}) : super(key: key);



  @override
  Widget build(BuildContext context){
    return BlocConsumer<InformasiBloc,InformasiState>(
      listener: (context,state){

      },
      builder: (context,state) {
        //return Container(
        if (state is InformasiErrorState) {
          return Text("Error");
        }
        if (state is InformasiLoadingState) {
          return CircularProgressIndicator();
        }
        if (state is AllInformasiLoadedState) {
          List<Informasi> list_informasi = state.list_informasi;
          List<String> list_image = [];
          for (var i = 0; i < list_informasi.length; i++) {
            list_image.add(list_informasi[i].images[0].url);
          }
          //return _buildImageCarouselWithIndicator(list_image, context);
          return Column(
            children: [
              CarouselSlider(
                options: CarouselOptions(
                  disableCenter: true,
                  onPageChanged: (index,reason){
                    //BlocProvider.of<InformasiBloc>(context).add(
                    //  InformasiPageChangeEvent(list_informasi:state.list_informasi,index:index)
                    //);
                    //current_pos = index;
                  },
                ),
                //items: list_image.map((imageUrl) {
                items: state.list_informasi.map((informasi){
                  return Ink(
                    width: double.infinity,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(30),
                      image: DecorationImage(
                        image: NetworkImage(
                          informasi.images[0].url
                          //fit: BoxFit.cover,
                        ),
                      ),
                    ),
                    child:InkWell(
                    splashColor: Colors.deepOrangeAccent,
                    onTap:() {
                      router.go('/beranda/informasi-details/'+informasi.id.toString());
                    },
                  ),
                  );
                }).toList(),
                //autoplay: true,
                //interval: Duration(seconds: 3),
              ),
            ],
          );
        }
        return Container();
      }
      );
      }

  }


