import 'dart:io';

import 'package:flutter/material.dart';
import 'package:aafmobile/repositories/service/asiafmobile.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:aafmobile/repositories/models/informasi.dart';
import 'package:aafmobile/repositories/asiafmobile.dart';
import 'package:equatable/equatable.dart';

part 'informasi_event.dart';
part 'informasi_state.dart';

/*
class InformasiBloc extends Bloc<InformasiEvent,InformasiState>{
  final AsiafMobileRepository asiafmobileRepository;

  InformasiBloc({
    required this.asiafmobileRepository,
  }):super(InformasiLoadingState());


  @override
  Stream<InformasiState> mapEventToState(
      InformasiEvent event,
      ) async* {
    if (event is GetAllInformasiEvent) {
      yield AllInformasiLoadedState(list_informasi: list_informasi,activePage: 0);
    } else if (event is InformasiPageChangeEvent) {
      yield InformasiPageChangeState(index: event.index);
      //yield ImageCarouselPageChanged(currentPageIndex: event.index);
    }
  }



  @override
  void onEvent(InformasiEvent event) async{
    if (event is GetAllInformasiEvent){
      final list_informasi = await asiafmobileRepository.getAllInformasi();
      emit(AllInformasiLoadedState(list_informasi: list_informasi, activePage: 0));
    }
  }


}

 */


class InformasiBloc extends Bloc<InformasiEvent,InformasiState>{
  final AsiafMobileRepository asiafmobileRepository;
  //int activePage=1;

  InformasiBloc({
//    required activePage,
    required this.asiafmobileRepository,
}): super(InformasiLoadingState()){
    on<GetAllInformasiEvent>(_mapGetAllInformasiEventToState);
 //   on<GetOneInformasiEvent>(_mapGetOneInformasiEventToState);
    on<InformasiPageChangeEvent>(_mapInformasiPageChangeEventToState);
  }


  void _mapGetAllInformasiEventToState(
      GetAllInformasiEvent event,Emitter<InformasiState> emit) async {
    emit(InformasiLoadingState());
    try{
      final list_informasi = await asiafmobileRepository.getAllInformasi();
      debugPrint("lagi diambil urlnya");
      print("informasi_bloc: $list_informasi");
      emit(AllInformasiLoadedState(list_informasi:list_informasi,activePage: 0));
      //yield AllInformasiLoadedState(list_informasi: list_informasi, activePage: 0);
    }catch(error,stacktrace){
      debugPrint(stacktrace.toString());
      emit(InformasiErrorState(error.toString()));
      //yield InformasiErrorState(error.toString());
    }
  }

  /*
  void _mapGetOneInformasiEventToState(
      GetOneInformasiEvent Event,Emitter<InformasiState> emit) async {
    emit(InformasiLoadingState());
    try{
      final informasi_item = await asiafmobileRepository.getOneInformasi(Event.data);
      emit(OneInformasiLoadedState(informasi: informasi_item));
      //emit(state.copyWith(status: InformasiStatus.selected,),);
    }catch(error,stacktrace){
      debugPrint(stacktrace.toString());
      emit(InformasiErrorState(error.toString()));
    }
  }

   */

  void _mapInformasiPageChangeEventToState(
      InformasiPageChangeEvent Event,
      Emitter<InformasiState> emit) async {
        try{
          //int activePage = Event.data;
          //emit(AllInformasiLoadedState(activePage:activePage));
          print("active page = $Event.index");
          //emit(InformasiPageChangeState(index:Event.index));
          emit(AllInformasiLoadedState(list_informasi:Event.list_informasi,activePage: Event.index));
          //yield InformasiPageChangeState(index:Event.index);
        }
        catch(error,stacktrace){
          debugPrint(stacktrace.toString());
          emit(InformasiErrorState(error.toString()));
          //yield InformasiErrorState(error.toString());
        }
      }



}

