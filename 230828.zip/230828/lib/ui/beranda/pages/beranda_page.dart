
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:aafmobile/repositories/asiafmobile.dart';
import 'package:aafmobile/ui/beranda/widgets/informasi_widget/bloc/informasi_bloc.dart';
import 'package:aafmobile/ui/beranda/widgets/productclassification_widget/bloc/productclassification_bloc.dart';
import 'package:aafmobile/ui/beranda/pages/beranda_layout.dart';
import 'package:aafmobile/repositories/service/asiafmobile.dart';


class BerandaPage extends StatelessWidget {
  const BerandaPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
    body:RepositoryProvider(
        create: (context) => AsiafMobileRepository(service: AsiafMobileService()),
        child: MultiBlocProvider(
          providers: [
            BlocProvider<InformasiBloc>(
              create: (context) => InformasiBloc(
                //activePage:1,
                asiafmobileRepository: context.read<AsiafMobileRepository>(),
              )..add(GetAllInformasiEvent()),
            ),

            BlocProvider<ProductClassificationBloc>(
              create: (context) => ProductClassificationBloc(
                asiafmobileRepository: context.read<AsiafMobileRepository>(),
              )..add(GetProductClassificationEvent()),
            ),

          ],
          child: BerandaLayout(),
        ),
      ),
    );
  }
}
