import 'package:flutter/material.dart';
//import 'package:aafmobile/ui/home/widgets/all_games_widget/all_games_widget.dart';
//import 'package:infogames/ui/home/widgets/category_widget/categories_widget.dart';
//import 'package:infogames/ui/home/widgets/games_by_category_widget/games_by_category_widget.dart';
//import 'package:infogames/ui/home/widgets/header_title/header_title.dart';
//import 'package:infogames/ui/widgets/container_body.dart';
import 'package:aafmobile/ui/beranda/widgets/informasi_widget/informasi_widget.dart';
import 'package:aafmobile/ui/beranda/widgets/productclassification_widget/productclassification_widget.dart';
import 'package:aafmobile/ui/beranda/pages/beranda_page.dart';
import 'package:aafmobile/ui/akun/pages/akun_page.dart';
import 'package:aafmobile/ui/promo/pages/promo_page.dart';
import 'package:aafmobile/ui/bantuan/pages/bantuan_page.dart';
import 'package:go_router/go_router.dart';
//import 'package:aafmobile/ui/beranda/widgets/category_widget//';

class BerandaLayout extends StatelessWidget{
  @override
  Widget build(BuildContext context){
    return Center(
      child:Column(
        children: <Widget>[
          Text("Informasi",style: const TextStyle(fontSize:20,fontWeight: FontWeight.bold)),
          Expanded(
            flex:5,
            child:InformasiWidget(),),
          Text("Product Classification",style: const TextStyle(fontSize:20,fontWeight: FontWeight.bold)),
          Expanded(
            //child:CategoryWidget(),),
            flex:5,
            child:ProductClassificationWidget(),
          ),
          Expanded(
            //child:ActivityWidget(),),
            child:Text("ActivityWidget"),
          ),
        ],
      ),
    );
  }
}